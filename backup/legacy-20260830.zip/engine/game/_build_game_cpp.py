#!/usr/bin/env python3
"""
Build game.cpp with ALL Game method implementations extracted from game_old.hpp.
Only extracts methods NOT already in sub-module files.
"""
import re, os

OLD = r"E:\reSF2\engine\game\game_old.hpp"
CPP = r"E:\reSF2\engine\game\game.cpp"

with open(OLD, 'r', encoding='utf-8') as f:
    text = f.read()

# Find the Game class body
m = re.search(r'class Game final[^{]*\{', text)
if not m:
    print("ERROR: Cannot find Game class")
    exit(1)

body_start = m.end()
depth = 0
body_end = body_start
for pos in range(body_start, len(text)):
    c = text[pos]
    if c == '{': depth += 1
    elif c == '}': depth -= 1
    if depth < 0:
        body_end = pos
        break

class_body = text[body_start:body_end]

# Methods that are DEFINITELY in sub-modules and should NOT be in game.cpp
submodule_methods = {
    'discover_locations',      # location_manager
    'set_start_location',      # location_manager
    'update_animation',        # animation_player (already in game.cpp)
    'play_animation',          # animation_player (already in game.cpp)
    'host_update_gameplay',    # game.cpp (already there)
    'load_location',           # location_manager
    'load_skeleton',           # asset_manager
    'load_body_model',         # asset_manager
    'load_punching_bag_model', # asset_manager  
    'load_enemy_weapon',       # asset_manager
    'load_player_weapon',      # asset_manager
    'load_animations',         # animation_player
    'load_moves',              # combat
    'init_bag_verlet',         # combat
    'apply_bag_impulse',       # combat
    'update_bag_verlet',       # combat
    'render_punching_bag',     # scene_renderer
    'load_loading_screen',     # asset_manager
    'render_loading_screen',   # scene_renderer
    'render_character',        # scene_renderer
    'render_enemy_fighter',    # scene_renderer
    'render_body_model',       # scene_renderer
    'render_location',         # scene_renderer
    'load_hud_font',           # hud_renderer  
    'load_hud_textures',       # hud_renderer
    'load_menu_textures',      # hud_renderer
    'load_texture_atlas_to_hud', # hud_renderer
    'load_sounds',             # audio
    'play_sound',              # audio
    'render_text',             # hud_renderer
    'render_hud',              # hud_renderer
    'render_menu_expanded',    # hud_renderer
    'render_menu_overlay',     # hud_renderer
    'render_dialog_overlay',   # hud_renderer
    'spawn_hit_sparks',        # combat
    'update_and_render_hit_sparks', # combat
    'spawn_projectile',        # combat
    'update_projectiles',      # combat
    'render_projectiles',      # scene_renderer
    'is_weapon_allowed',       # combat
    'cycle_weapon',            # combat
    'weapon_tactic_to_model_file', # asset_manager
    'load_location',           # location_manager
    'parse_body_model_xml',    # asset_manager
    'resolve_body_node',       # scene_renderer
    'update_animation',        # animation_player
    'play_animation',          # animation_player
    'update_projectiles',      # combat
    'render_projectiles',      # scene_renderer
}

# Methods that should be in game.cpp (Game class methods not in sub-modules)
game_cpp_methods = [
    'on_init',
    'on_update', 
    'on_render',
    'on_shutdown',
    'request_scene_transition',
    'host_load_location',
    'host_reset_menu_state',
    'host_load_battle_location',
    'host_location_loaded',
    'host_save_progress',
    'host_load_progress',
    'host_set_dialogue',
    'host_get_dialogue',
    'host_set_current_level',
    'host_add_completed_level',
    'host_is_level_completed',
    'host_get_battle_result',
    'host_get_stages',
    'host_set_battle_location',
    'host_get_battle_location',
    'host_set_battle_result',
    'host_get_currency',
    'host_spend_currency',
    'host_add_currency',
    'host_has_item',
    'host_get_owned_items',
    'host_get_equipped',
    'host_buy_item',
    'host_sell_item',
    'host_equip_item',
    'host_unequip_item',
    'host_get_player_level',
    'host_get_wins',
    'host_get_losses',
    'host_get_list_data',
    'host_get_current_level',
    'host_add_win',
    'host_add_loss',
    'sync_equipped_weapon',
    'host_start_menu_music',
    'host_start_battle_music',
    'host_stop_music',
    'host_play_ui_click',
    'host_play_result_sound',
    'host_render_text',
    'host_render_zone_bg',
    'host_set_show_enemy',
    'host_set_battle_mode',
    'host_render_scene',
    'host_render_loading',
    'init_location',
]

# Now find each method's body in class_body using signature matching
# Simple regex approach: find the start of each method and extract its body

def clean(s):
    """Remove string literals for easier parsing."""
    return re.sub(r'"[^"]*"', '', s)

def extract_method_body(full_text, method_name, start_pos=0):
    """Find a method named method_name in full_text and return (signature, body, end_pos)."""
    # Look for patterns like: "return_type method_name(" or "method_name(" after return type
    # Search from start_pos
    
    # Build pattern to find this method's signature
    # Pattern matches: return_type + method_name + ( ... ) { 
    # or: method_name( ... ) {
    # where it's a method (not in a comment, not in a string)
    
    # Strategy: find occurrences of method_name( in the text
    # For each occurrence, check if it looks like a method definition
    # by looking at what precedes it (should be a return type or start of line after whitespace)
    
    pos = start_pos
    while pos < len(full_text):
        idx = full_text.find(method_name + '(', pos)
        if idx < 0:
            return None, None, -1
        
        # Check this isn't inside a comment
        before = full_text[max(0, idx-200):idx]
        if '//' in before:
            last_comment = before.rindex('//')
            last_nl = before.rindex('\n') if '\n' in before else 0
            if last_comment > last_nl:
                pos = idx + 1
                continue
        
        # Find the matching ) that ends the parameter list
        paren_depth = 0
        param_start = idx + len(method_name)
        for p in range(param_start, len(full_text)):
            c = full_text[p]
            if c == '(': paren_depth += 1
            elif c == ')': 
                paren_depth -= 1
                if paren_depth == 0:
                    # Found end of params
                    params_end = p
                    break
        
        # Look for { after the params
        after_params = full_text[params_end+1:params_end+100]
        
        # Skip const/override/noexcept
        rest = after_params.lstrip()
        # Remove qualifiers
        while True:
            old = rest
            rest = re.sub(r'^(const|override|noexcept|throw\s*\([^)]*\))\s*', '', rest)
            if rest == old:
                break
        
        brace_pos = -1
        if rest.startswith('{'):
            brace_pos = params_end + 1 + (len(after_params) - len(rest))
        
        if brace_pos < 0:
            pos = idx + 1
            continue
        
        # Found method! Extract signature
        sig_start = idx
        # Walk backward to find the beginning of the return type
        while sig_start > 0:
            c = full_text[sig_start-1]
            if c in '\n\r':
                break
            if c == ';' or c == '}':
                sig_start_adj = sig_start
                # Check if we're looking at something after "}\n" 
                break
            sig_start -= 1
        
        sig = full_text[sig_start:params_end+1].strip()
        
        # Collect body using brace matching
        body_depth = 1
        body_end = brace_pos + 1
        for q in range(brace_pos + 1, len(full_text)):
            c = full_text[q]
            if c == '{': body_depth += 1
            elif c == '}': body_depth -= 1
            if body_depth == 0:
                body_end = q
                break
        
        body = full_text[brace_pos+1:body_end].strip()
        
        # Check that the signature really matches our method name  
        if method_name in sig:
            return sig, body, body_end
        
        pos = idx + 1
    
    return None, None, -1

# Extract all methods for game.cpp
print("Extracting Game methods...")
extracted = []

for method_name in game_cpp_methods:
    sig, body, end = extract_method_body(class_body, method_name)
    if sig is None:
        print(f"  NOT FOUND: {method_name}")
        continue
    
    # Add Game:: scope to signature
    # sig is something like "void Game::on_init(plat::Platform& platform)"
    # But since it's from class_body, it won't have Game:: 
    # Find the return type + name pattern
    m2 = re.match(r'^((?:virtual\s+|static\s+)?(?:\w[\w\s:*&]*\s+))?(\w[\w:~]*)(\s*\()', sig)
    if m2:
        ret = m2.group(1) or ''
        name = m2.group(2)
        rest_sig = sig[m2.end(2):]
        scoped = f"{ret}Game::{name}{rest_sig}"
    else:
        scoped = f"Game::{sig}"
    
    extracted.append((scoped, body, method_name))
    print(f"  FOUND: {method_name}")

# Now write game.cpp
print(f"\nWriting game.cpp with {len(extracted)} methods...")

with open(CPP, 'w', encoding='utf-8') as f:
    f.write("// engine/game/game.cpp\n")
    f.write("//\n")
    f.write("// Game class implementation — extracted from game.hpp inline bodies.\n\n")
    f.write("#include \"game.hpp\"\n")
    f.write("\n")
    f.write("#include <algorithm>\n")
    f.write("#include <cstring>\n")
    f.write("#include <fstream>\n")
    f.write("#include <cstdio>\n")
    f.write("#include <filesystem>\n")
    f.write("\n")
    f.write("namespace resf2::game {\n\n")
    
    for sig, body, name in extracted:
        # Format body with proper indentation
        indented_body = '\n'.join('    ' + l if l.strip() else l for l in body.split('\n'))
        f.write(f"{sig} {{\n{indented_body}\n}}\n\n")
    
    f.write("} // namespace resf2::game\n")

print(f"Done! game.cpp has {len(open(CPP).readlines())} lines")
