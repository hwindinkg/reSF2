#!/usr/bin/env python
"""Remove inline method bodies from game_clean.hpp that are now in game.cpp"""
import re

with open(r'E:\reSF2\engine\game\game_clean.hpp', 'r') as f:
    content = f.read()

game_cpp_methods = [
    'on_init', 'on_update', 'on_render', 'on_shutdown',
    'request_scene_transition', 'host_load_location', 'host_reset_menu_state',
    'host_load_battle_location', 'host_location_loaded',
    'host_save_progress', 'host_load_progress',
    'host_set_dialogue', 'host_get_dialogue',
    'host_set_current_level', 'host_add_completed_level', 'host_is_level_completed',
    'host_get_battle_result', 'host_get_stages', 'host_set_battle_location',
    'host_get_battle_location', 'host_set_battle_result',
    'host_get_currency', 'host_spend_currency', 'host_add_currency',
    'host_has_item', 'host_get_owned_items', 'host_get_equipped',
    'host_buy_item', 'host_sell_item', 'host_equip_item', 'host_unequip_item',
    'host_get_player_level', 'host_get_wins', 'host_get_losses',
    'host_get_list_data', 'host_get_current_level',
    'host_add_win', 'host_add_loss', 'sync_equipped_weapon',
    'host_start_menu_music', 'host_start_battle_music', 'host_stop_music',
    'host_play_ui_click', 'host_play_result_sound',
    'host_render_text', 'host_render_zone_bg',
    'host_set_show_enemy', 'host_set_battle_mode',
    'host_render_scene', 'host_render_loading', 'init_location'
]

removed_count = 0
for method in game_cpp_methods:
    idx = 0
    while True:
        pos = content.find(method + '(', idx)
        if pos < 0:
            break

        # Walk backward to find the beginning of the line
        line_start = content.rfind('\n', 0, pos) + 1

        # Check we're not in a comment
        pre_text = content[max(0, pos-500):pos]
        if '//' in pre_text:
            last_comment = pre_text.rindex('//')
            last_nl = pre_text.rfind('\n')
            if last_comment > last_nl:
                idx = pos + 1
                continue

        # Find the end of the parameter list
        paren_depth = 0
        params_end = -1
        for i in range(pos + len(method), len(content)):
            c = content[i]
            if c == '(':
                paren_depth += 1
            elif c == ')':
                paren_depth -= 1
                if paren_depth == 0:
                    params_end = i
                    break

        if params_end < 0:
            idx = pos + 1
            continue

        # Look for { after the params
        after_params = content[params_end+1:params_end+200]
        rest = after_params.lstrip()

        # Skip const/override/noexcept
        while True:
            old = rest
            rest = re.sub(r'^(const|override|noexcept|&\s*const)\s+', '', rest)
            if rest == old:
                break
        # Also handle trailing &
        rest = re.sub(r'^&\s*', '', rest).lstrip()

        if not rest.startswith('{'):
            idx = pos + 1
            continue

        # Find the matching closing brace
        body_start = params_end + 1 + (len(after_params) - len(rest))
        depth = 1
        body_end = body_start + 1
        for i in range(body_start + 1, len(content)):
            c = content[i]
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    body_end = i + 1
                    break

        # Get signature from start of line to {
        signature = content[line_start:body_start].strip()
        if signature.endswith('{'):
            signature = signature[:-1].strip()

        # Clean up trailing inline comments
        sig_clean = re.sub(r'//.*$', '', signature).strip()

        replacement = sig_clean + ';'

        print(f'  REMOVED: {method}')
        content = content[:line_start] + replacement + '\n' + content[body_end:]
        removed_count += 1
        break

print(f'\nConverted {removed_count} inline methods to declarations')

with open(r'E:\reSF2\engine\game\game_clean.hpp', 'w') as f:
    f.write(content)
print('Written to game_clean.hpp')
