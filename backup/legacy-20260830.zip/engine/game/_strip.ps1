# Robust inline method body stripper for game.hpp
# Uses two-pass approach to be safe with nested braces

param(
    [string]$InputFile = "E:\reSF2\engine\game\game.hpp",
    [string]$HeaderOut = "E:\reSF2\engine\game\game_clean.hpp",
    [string]$BodiesOut = "E:\reSF2\engine\game\_bodies.cpp"
)

# Read entire file as single string with original line endings
$content = [System.IO.File]::ReadAllText($InputFile)
$lines = $content -split "`r?`n"
$origEnding = if ($content -match "`r`n") { "`r`n" } else { "`n" }

Write-Host "Input: $($lines.Length) lines"

# PASS 1: Find all method body ranges using brace-counting
# We track the "class depth" (inside Game { }) and detect when we're inside a method body

$braceDepth = 0
$inClass = $false
$methodStartLines = @()  # lines where method signature starts with {
$classBraceLine = -1

# Track string/comment state per character
function Get-BraceDepth {
    param([string]$text, [ref]$depthRef, [ref]$inStr, [ref]$inCh, [ref]$inBC)
    
    for ($i = 0; $i -lt $text.Length; $i++) {
        $ch = $text[$i]
        $nxt = if ($i + 1 -lt $text.Length) { $text[$i + 1] } else { '' }
        
        if ($inBC.Value) {
            if ($ch -eq '*' -and $nxt -eq '/') { $inBC.Value = $false; $i++ }
            continue
        }
        if ($inStr.Value) {
            if ($ch -eq '"' -and ($i -eq 0 -or $text[$i-1] -ne '\')) { $inStr.Value = $false }
            continue
        }
        if ($inCh.Value) {
            if ($ch -eq "'" -and ($i -eq 0 -or $text[$i-1] -ne '\')) { $inCh.Value = $false }
            continue
        }
        
        if ($ch -eq '/' -and $nxt -eq '/') { break }  # line comment
        if ($ch -eq '/' -and $nxt -eq '*') { $inBC.Value = $true; $i++; continue }
        if ($ch -eq '"') { $inStr.Value = $true; continue }
        if ($ch -eq "'") { $inCh.Value = $true; continue }
        
        if ($ch -eq '{') { $depthRef.Value++ }
        if ($ch -eq '}') { $depthRef.Value-- }
    }
}

# Actually, let me take an even simpler approach.
# I'll scan line by line and detect inline method bodies by:
# 1. Looking for method signatures (lines that match a method pattern and end with {)
# 2. Using brace counting to find the matching }

$inBlockComment = $false
$i = 0
$outputLines = @()
$bodyAccum = @()
$extractedCount = 0
$inlineCount = 0

while ($i -lt $lines.Length) {
    $raw = $lines[$i]
    $trimmed = $raw.Trim()
    
    # Check if line starts a method with inline body
    # A method signature ends with `{` possibly after override/const,
    # and starts with a return type or class name
    
    # Determine if this is a method signature line (starts method with inline body)
    $isMethodSig = $false
    $openBracePos = -1
    
    if (!$inBlockComment) {
        # Remove block comments for detection
        $detectLine = $raw
        $detectLine = [regex]::Replace($detectLine, '/\*.*?\*/', '')
        
        # Find all { characters not in strings
        $noStrings = ""
        $inStr2 = $false
        for ($j = 0; $j -lt $detectLine.Length; $j++) {
            $c = $detectLine[$j]
            if ($c -eq '"') { $inStr2 = !$inStr2; $noStrings += $c }
            elseif ($inStr2) { $noStrings += $c }
            else { $noStrings += $c }
        }
        
        # Find the position of { that ends a method signature
        $braceIdx = $noStrings.IndexOf('{')
        
        if ($braceIdx -ge 0) {
            $beforeBrace = $noStrings.Substring(0, $braceIdx).TrimEnd()
            
            # Check if what precedes the { looks like a method signature
            # Pattern: ends with ) possibly with const/override/noexcept/&
            # This should be a method return type pattern
            $looksLikeMethod = $false
            
            if ($beforeBrace -match '\)$') {
                # Ends with ) - definitely a method/function signature
                # But could be a lambda or if/for/while
                # Check what starts the line
                $lineStart = $trimmed -replace '\s*\{.*$', ''
                
                if ($lineStart -match '^(if|for|while|switch|else|catch)\b') {
                    $looksLikeMethod = $false  # control flow
                } elseif ($lineStart -match '^\[') {
                    $looksLikeMethod = $false  # lambda or attribute
                } elseif ($lineStart -match '^\s*(void|bool|int|float|double|char|uint|size_t|long|short|auto|const|std::|static |virtual |explicit |inline |resf2::)') {
                    $looksLikeMethod = $true
                } elseif ($beforeBrace -match '^\s*~?\w+\(' -or $beforeBrace -match '^\s*\w+::') {
                    # Constructor/destructor or method with scope
                    $looksLikeMethod = $true
                } elseif ($beforeBrace -match 'operator') {
                    $looksLikeMethod = $true
                } elseif ($lineStart -match '^\w[\w:]*\(' -or $lineStart -match '^\w[\w:]*\s*\(') {
                    # Just a name followed by ( - could be constructor
                    $looksLikeMethod = $true
                }
            } elseif ($beforeBrace -match '\))' -or $beforeBrace -match '\)\s+(const|override|noexcept|throw)') {
                # Multi-arg with no space before (
                $looksLikeMethod = $true
            }
        }
    }
    
    if ($isMethodSig) {
        # This starts an inline method body
        # Output the signature with ; instead of { ... }
        $sigPart = $raw.Substring(0, $openBracePos).TrimEnd()
        $trailingComment = ""
        $afterBrace = $raw.Substring($openBracePos + 1)
        
        # Check if there's a trailing comment on the sig line
        $sigLineComment = ""
        if ($raw -match '//') {
            $commentPos = $raw.IndexOf('//')
            if ($commentPos -gt $openBracePos) {
                $sigLineComment = $raw.Substring($commentPos)
            }
        }
        
        # If the { also closes on this line (single-line method), extract the body
        $closeBraceIdx = $afterBrace.IndexOf('}')
        if ($closeBraceIdx -ge 0) {
            # Single-line inline: `void foo() { return; }`
            $bodyText = $afterBrace.Substring(0, $closeBraceIdx).Trim()
            $restAfterClose = $afterBrace.Substring($closeBraceIdx + 1).Trim()
            
            # Check if it's a trivial getter/setter
            $isTrivial = $false
            if ($bodyText -match '^return\s+\w+[_\.].*;\s*$' -and $bodyText.Length -lt 60) { $isTrivial = $true }
            if ($bodyText -match '^return\s+\w+;\s*$') { $isTrivial = $true }
            if ($bodyText.Length -eq 0) { $isTrivial = $true }
            
            if ($isTrivial) {
                # Keep as inline
                $outputLines += $raw
                $inlineCount++
            } else {
                # Convert to declaration
                $outputLines += "$sigPart;$trailingComment".TrimEnd()
                $bodyAccum += "    $bodyText"
                $extractedCount++
            }
            $i++
            continue
        }
        
        # Multi-line body - track to find matching }
        $outputLines += "$sigPart;"
        $bodyLines = @()
        if ($afterBrace.Trim().Length -gt 0) {
            $bodyLines += "        $($afterBrace.Trim())"
        }
        $bodyDepth = 1
        
        # Count braces in afterBrace part
        $noStrA = ""
        $inS = $false
        foreach ($c in $afterBrace.GetEnumerator()) {
            if ($c -eq '"') { $inS = !$inS }
            if (!$inS) { $noStrA += $c }
        }
        foreach ($c in $noStrA.GetEnumerator()) {
            if ($c -eq '{') { $bodyDepth++ }
            if ($c -eq '}') { $bodyDepth-- }
        }
        
        # Continue reading lines until bodyDepth <= 0
        $i++
        while ($i -lt $lines.Length -and $bodyDepth -gt 0) {
            $bodyLine = $lines[$i]
            
            # Strip comments and count braces
            $cleanLine = [regex]::Replace($bodyLine, '//.*$', '')
            $cleanLine = [regex]::Replace($cleanLine, '"[^"]*"', '""')
            $cleanLine = [regex]::Replace($cleanLine, "'[^']*'", "''")
            $cleanLine = [regex]::Replace($cleanLine, '/\*.*?\*/', '')
            
            foreach ($c in $cleanLine.GetEnumerator()) {
                if ($c -eq '{') { $bodyDepth++ }
                if ($c -eq '}') { $bodyDepth-- }
            }
            
            $bodyLines += $bodyLine
            $i++
        }
        
        # Remove the last closing brace from body lines
        if ($bodyLines.Count -gt 0) {
            $lastLine = $bodyLines[-1]
            # Remove trailing } (just the closure)
            $lastClean = $lastLine -replace '^\s*\}\s*', ''
            if ($lastClean.Trim().Length -eq 0 -or $lastClean.Trim() -match '^//') {
                $bodyLines[-1] = $lastLine -replace '\s*\}\s*.*$', ''
            } else {
                $bodyLines[-1] = $lastLine -replace '^\s*\}\s*', ''
            }
            if ($bodyLines[-1].Trim().Length -eq 0) {
                $bodyLines = $bodyLines[0..($bodyLines.Count-2)]
            }
        }
        
        $extractedCount++
        $bodyAccum += @($bodyLines -join "`n")
        continue
    }
    
    # Regular line - pass through
    $outputLines += $raw
    $i++
}

# Write the header
$outputLines -join $origEnding | Out-File -FilePath $HeaderOut -Encoding UTF8 -NoNewline
Write-Host "Output header: $($outputLines.Length) lines"
Write-Host "Extracted methods: $extractedCount (kept $inlineCount inline)"
Write-Host "Total body lines: $($bodyAccum.Count)"
