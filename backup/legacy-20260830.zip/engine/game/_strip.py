#!/usr/bin/env python3
"""Strip inline method bodies from game.hpp, keep only declarations + member vars."""

import re
import sys

INPUT = r"E:\reSF2\engine\game\game.hpp"
HEADER_OUT = r"E:\reSF2\engine\game\game.hpp"  # overwrite in place
BODIES_OUT = r"E:\reSF2\engine\game\game_new_bodies.cpp"

with open(INPUT, 'r', encoding='utf-8') as f:
    lines = f.readlines()

# We'll build the output header and the extracted bodies
out_lines = []
extracted_bodies = []

# Track state
i = 0
in_class = False
brace_depth = 0  # tracks overall brace depth

# For detecting multi-line method signatures and their bodies
sig_prefix = ""  # accumulated signature prefix for multi-line sigs
in_method_body = False
method_body_depth = 0
method_body_lines = []

# Helper: strip strings and comments from a line for brace counting
def strip_for_brace_count(line):
    """Remove string literals, char literals, line comments, and block comments from line."""
    result = ""
    in_string = False
    in_char = False
    in_block = False
    i = 0
    while i < len(line):
        c = line[i]
        n = line[i+1] if i+1 < len(line) else ''
        
        if in_block:
            if c == '*' and n == '/':
                in_block = False
                i += 2
                continue
            i += 1
            continue
        
        if c == '"' and not in_char:
            in_string = not in_string
            result += c
            i += 1
            continue
        if c == "'" and not in_string:
            in_char = not in_char
            i += 1
            continue
        
        if in_string or in_char:
            result += c
            i += 1
            continue
        
        if c == '/' and n == '/':
            break  # rest is line comment
        if c == '/' and n == '*':
            in_block = True
            i += 2
            continue
        
        result += c
        i += 1
    
    return result

# Heuristic: does this line start a method declaration with inline body?
def looks_like_method_sig(line):
    """Check if a non-comment non-empty line looks like the start of a method sig."""
    trimmed = line.strip()
    if not trimmed:
        return False
    
    # Remove strings for detection
    cleaned = strip_for_brace_count(trimmed)
    # Remove trailing comments  
    cleaned = re.sub(r'//.*$', '', cleaned).strip()
    
    if not cleaned:
        return False
    
    # Check if it ends with { (possibly with spaces)
    if not cleaned.endswith('{'):
        # Check if it could be a multi-line sig where { is on next line
        if cleaned.endswith(')') or cleaned.rstrip().endswith(')') or ')' in cleaned:
            # Could be first line of multi-line signature  
            return True
        return False
    
    # Find where { starts
    brace_pos = cleaned.index('{')
    before_brace = cleaned[:brace_pos].strip()
    
    # Check if before { looks like a method signature (ends with ) or const ) or override ))
    # Patterns: ){, ) const{, ) override{, ) noexcept{, ) const override{, etc
    # Remove trailing keywords before checking for closing paren
    sig_check = before_brace
    sig_check = re.sub(r'\b(const|override|noexcept|throw\s*\([^)]*\))\s*$', '', sig_check).strip()
    
    if not sig_check.endswith(')'):
        return False
    
    # It ends with ){ or ) const{ etc - could be method
    # Check that it's not a control flow keyword
    first_word = sig_check.split()[0] if sig_check.split() else ''
    control_keywords = {'if', 'for', 'while', 'switch', 'else', 'catch', 'try'}
    if first_word in control_keywords:
        return False
    
    # Could be constructor/destructor or method - let's check if the sig has a return type
    # or is a constructor (starts with ~ or a word followed by ()
    if (re.match(r'^(void|bool|int|float|double|char|uint\d*_t|int\d+_t|size_t|long|short|auto|const|std::|static |virtual |explicit |inline |resf2::|~)', before_brace) or
        re.match(r'^\w[\w:]*\s*\(', before_brace)):  # method name starts with (
        return True
    
    return False

# Main processing loop
while i < len(lines):
    line = lines[i]
    raw_line = line.rstrip('\n').rstrip('\r')
    
    if in_method_body:
        # We are collecting a method body
        clean = strip_for_brace_count(line)
        for c in clean:
            if c == '{':
                method_body_depth += 1
            elif c == '}':
                method_body_depth -= 1
        
        method_body_lines.append(line)
        
        if method_body_depth <= 0:
            # Method body finished
            in_method_body = False
            # Remove last closing brace from body_lines
            if method_body_lines:
                last = method_body_lines[-1]
                # Strip the trailing } (or the line that has it)
                body_text = ''.join(method_body_lines)
                body_text = body_text.rstrip()
                # Remove single trailing } if it's the last non-whitespace char
                if body_text.endswith('}'):
                    body_text = body_text[:-1]
                body_text = body_text.strip()
                if body_text:
                    extracted_bodies.append(body_text)
                method_body_lines = []
        i += 1
        continue
    
    # Check if this line (possibly continuing a multi-line sig) starts a method body
    clean_line = strip_for_brace_count(line)
    
    # Handle multi-line signatures (where { is on the next line after the closing paren)
    # Simple case: line ends with {
    if '{' in clean_line:
        # Check if { is part of a method start or something else
        brace_idx = clean_line.index('{')
        before_brace = line[:brace_idx + (len(line) - len(clean_line))].rstrip()
        
        if looks_like_method_sig(line):
            # This is an inline method body
            # Extract just the signature part (before {)
            sig = before_brace
            
            # Check if there's content after { on the same line
            after_brace_idx = line.index('{', brace_idx)
            after_brace = line[after_brace_idx + 1:] if after_brace_idx + 1 < len(line) else ''
            
            # Check for one-liner: } on same line after non-trivial body
            close_idx = after_brace.rfind('}')
            if close_idx >= 0:
                # One-liner method: void foo() { return x; }
                body_content = after_brace[:close_idx].strip()
                # Check if trivial enough to keep inline
                trivial_patterns = [
                    r'^return\s+\w+[_\.].*;\s*$',
                    r'^return\s+\w+;\s*$',
                    r'^\w+_\s*=\s*.*;\s*$',
                    r'^\w+\(.*\);\s*$',
                    r'^$',  # empty body
                ]
                is_trivial = any(re.match(p, body_content) for p in trivial_patterns)
                
                # Also check for setter patterns like is_battle_mode_ = battle
                if ('host_set_battle_mode' in sig):
                    is_trivial = True
                
                if is_trivial and len(body_content) < 80:
                    # Keep inline - trivial getter/setter
                    out_lines.append(line)
                else:
                    # Replace with just the signature + semicolon
                    # Handle trailing comments
                    comment = ''
                    if '//' in line:
                        ci = line.index('//')
                        comment = line[ci:]
                        sig = sig.rstrip()
                    
                    out_lines.append(f"{sig};\n")
                    if body_content:
                        extracted_bodies.append(f"    {body_content}")
            else:
                # Multi-line body
                out_lines.append(f"{sig};\n")
                
                # Check what's after { on the first line
                body_start = after_brace.strip()
                method_body_lines = []
                if body_start:
                    method_body_lines.append(f"        {body_start}\n")
                
                # Count braces in after_brace
                method_body_depth = 1
                for c in strip_for_brace_count(after_brace):
                    if c == '{':
                        method_body_depth += 1
                    elif c == '}':
                        method_body_depth -= 1
                
                if method_body_depth <= 0:
                    # Body ended on the same line (shouldn't happen as we handled one-liner above)
                    pass
                else:
                    in_method_body = True
        else:
            # Not a method sig - keep line as-is
            out_lines.append(line)
    else:
        # No { in this line - check if it could be start of multi-line sig
        # where { is on next line
        # This handles: return_type\nmethod_name(params)\n{
        # Look ahead for next non-comment non-empty line ending with {
        
        # For now, just pass through
        out_lines.append(line)
    
    i += 1

# Write output header
with open(HEADER_OUT, 'w', encoding='utf-8') as f:
    f.writelines(out_lines)

# Write extracted bodies
with open(BODIES_OUT, 'w', encoding='utf-8') as f:
    f.write("// Extracted method bodies from game.hpp inline definitions\n")
    f.write("namespace resf2::game {\n\n")
    for body in extracted_bodies:
        f.write(body)
        f.write("\n\n")
    f.write("} // namespace resf2::game\n")

print(f"Header lines: {len(out_lines)} (was {len(lines)})")
print(f"Extracted method bodies: {len(extracted_bodies)}")
print(f"Reduction: {len(lines) - len(out_lines)} lines removed")
