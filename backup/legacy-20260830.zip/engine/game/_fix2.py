#!/usr/bin/env python3
"""Fix corrupted signatures in game_new.hpp using regex."""
import re

with open(r"E:\reSF2\engine\game\game_new.hpp", 'r', encoding='utf-8') as f:
    content = f.read()
    lines = content.split('\n')

fixed = []
for line in lines:
    original = line
    
    # Pattern: a method declaration with inline body that was corrupted
    # e.g.: "    void discover_locations() {void discover_locations();"
    # We need to replace this with: "    void discover_locations();"
    
    # Match lines where:
    # 1. They start with some whitespace
    # 2. Have a return type / method declaration ending with )
    # 3. Followed by { 
    # 4. Followed by the same declaration text
    # 5. Followed by ;
    
    # Pattern: optional return-type/qualifiers, method-name, params in parens, optional qualifiers, then { same-thing ;
    # The key is the duplication between { and ;
    
    # Try to match using capture groups
    # Match: some-whitespace + "type name(params, ...)" + optional "const/override" + optional " " + "{" + same-pattern + ";"
    
    # Alternative simpler pattern: match lines that have { followed by ; where what's between them
    # looks like a method signature repeated
    
    # Check if line has both { and ;
    if '{' in line and ';' in line:
        brace_idx = line.index('{')
        semi_idx = line.index(';')
        
        if semi_idx > brace_idx:
            # Extract text between { and ;
            between = line[brace_idx + 1:semi_idx].strip()
            before_brace = line[:brace_idx].rstrip()
            
            # If the text between matches what's before the brace, it's corrupted
            if between == before_brace.strip():
                # Fix: replace with declaration
                fixed_line = before_brace + ';'
                # Keep trailing comment if any
                if '//' in line[semi_idx + 1:]:
                    ci = line.index('//', brace_idx)
                    fixed_line = before_brace + ';  ' + line[ci:]
                line = fixed_line
    
    # Another pattern: multi-line corrupted like:
    # "void host_render_text(...) const override {\n    void host_render_text(...) const override;"
    # This won't be caught by the single-line check above
    
    fixed.append(line)

result = '\n'.join(fixed)

# Count how many corrupted signatures remain
remaining = len(re.findall(r'\{.*\(.*\).*;\s*$', result, re.MULTILINE))
print(f"Lines: {len(fixed)}")
print(f"Likely still corrupted: {remaining}")

# Check a few lines
for i, line in enumerate(fixed):
    if '{' in line and ';' in line and line.index('{') < line.index(';'):
        # Check if it still has the corrupted pattern
        brace_idx = line.index('{')
        semi_idx = line.index(';')
        between = line[brace_idx + 1:semi_idx].strip()
        before = line[:brace_idx].strip()
        if between == before:
            print(f"Line {i+1}: STILL CORRUPTED: {line.strip()[:80]}...")

with open(r"E:\reSF2\engine\game\game_new.hpp", 'w', encoding='utf-8') as f:
    f.write(result)

print("\nDone")
