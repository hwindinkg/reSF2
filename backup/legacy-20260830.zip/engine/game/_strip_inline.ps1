# Strip inline method bodies from game.hpp and append them to game.cpp
# Uses brace-depth tracking with string/comment awareness

$inputFile = "E:\reSF2\engine\game\game.hpp"
$headerOut = "E:\reSF2\engine\game\game_new.hpp"
$cppAppend = "E:\reSF2\engine\game\_extracted_bodies.cpp"

$lines = Get-Content $inputFile
$outLines = @()
$extractedBodies = @()
$classDepth = 0          # tracks brace depth inside class
$extractingBody = $false # are we extracting a method body?
$bodyDepth = 0           # brace depth inside the method body
$bodyLines = @()         # accumulated method body lines
$inComment = $false      # block comment state
$preserveMethod = $false # true if this is a trivial getter (keep inline)

for ($i = 0; $i -lt $lines.Count; $i++) {
    $raw = $lines[$i]
    $line = $raw

    # Handle block comments
    if ($inComment) {
        $outLines += $raw
        if ($raw -match '\*/') { $inComment = $false }
        continue
    }
    if ($raw -match '/\*') { 
        if ($raw -notmatch '\*/') { $inComment = $true }
        $outLines += $raw
        continue
    }

    if ($extractingBody) {
        # We're inside a method body - track depth
        $bodyLines += $raw
        
        # Count braces, but ignore strings
        $stripped = $raw
        # Remove string literals for brace counting
        $stripped = [regex]::Replace($stripped, '"[^"]*"', '""')
        $stripped = [regex]::Replace($stripped, "'[^']*'", "''")
        
        foreach ($ch in $stripped.GetEnumerator()) {
            if ($ch -eq '{') { $bodyDepth++ }
            if ($ch -eq '}') { $bodyDepth-- }
        }
        
        if ($bodyDepth -le 0) {
            # Method body ended
            $extractingBody = $false
            # Instead of appending to outLines, write extracted body
            $extractedBodies += @($bodyLines -join "`n")
            # Emit just "    }" with a newline to close the method in the header
            # Actually no - we replace the body with ";"
            # We need to re-emit just the method signature line with ";" instead of "{ ... }"
            # This is handled by the logic below - we already output the sig line, we just skip the body.
        }
        continue
    }

    # Check if we need to start extracting a method body
    # A method body starts with a line like: `void foo(...) {` or `{` on its own line
    
    # First, check if this line is a class-level opening brace or closing
    if ($raw -match 'class Game final') {
        $classDepth++
        $outLines += $raw
        continue
    }
    
    # Check for }; at class level (end of class)
    if ($raw -match '^\s*\}\s*;\s*$' -or $raw -match '^\s*\}\s*//') {
        # Do brace counting properly
        $trimmed = $raw.TrimStart()
        # Check if we're in a method body (shouldn't happen at this point in the code)
        $outLines += $raw
        $classDepth--
        continue
    }

    # Detect if this is a method declaration with inline body
    # Pattern: line ends with `{` possibly with `override` or `const` before it
    $trimmed = $raw.Trim()
    
    # Skip empty lines, comments, preprocessor directives  
    if ([string]::IsNullOrEmpty($trimmed) -or $trimmed -match '^//' -or $trimmed -match '^#') {
        $outLines += $raw
        continue
    }

    # Check for method signature: return type + name + params ending with ) { or ) const { or ) override { etc
    # The key pattern is that the line ends with `{` (possibly after whitespace/comments)
    # AND is a method declaration (has return type pattern)
    
    # First, let's try a simpler approach: check if line starts a method body
    # by looking at whether it's a declaration ending with {
    
    # A line is a method signature with inline body if it:
    # 1. Ends with `{` (possibly with trailing comment) 
    # 2. Is not part of a class/struct/namespace/enum definition
    # 3. Has a return type or is a constructor/destructor
    
    $lineForCheck = $raw
    # Remove trailing comments
    $lineForCheck = $raw -replace '//.*$', ''
    $lineForCheck = $lineForCheck.TrimEnd()
    
    $isInlineMethod = $false
    $sigLine = $raw
    
    if ($lineForCheck -match '\{\s*$') {
        # Line ends with {
        # Check if it looks like a method declaration (has return type pattern)
        # or constructor/destructor
        $looksLikeMethod = $false
        
        # Patterns that indicate a method declaration:
        # - return type at start: void|bool|int|float|std::|const |uint|size_t|char|static |virtual
        # - constructor/destructor: ClassName( or ~ClassName(
        # - operator overloading: operator
        if ($raw -match '^\s+(void|bool|int|float|uint32_t|uint64_t|size_t|char|const |std::|static |virtual |explicit )' -or
            $raw -match '^\s+~Game' -or
            $raw -match '^\s+operator\s' -or
            # Multi-line signature continuation (just '{' on its own line)
            $raw -match '^\s+\{\s*$') {
            $looksLikeMethod = $true
        }
        
        # Check for combined declaration+body on same line: `bool foo() { return x; }`
        # If the entire body is on one line and it's trivial (one-liner), we can keep it inline
        if ($looksLikeMethod -and $raw -match '\{.*\}\s*$') {
            # One-liner method - check if trivial getter/setter
            $bodyText = ($raw -replace '^.*\{', '') -replace '\}\s*$', ''
            $bodyText = $bodyText.Trim()
            
            # Trivial getters: `return member_;` or `return member_.method();`
            # Trivial setters: `member_ = value;`
            if ($bodyText -match '^return\s+\w+[_\.].*;\s*$' -or
                $bodyText -match '^return\s+\w+;\s*$' -or
                $bodyText -match '^\w+_\s*=\s*.*;\s*$' -or
                $bodyText -match '^\w+\(.*\)\s*;\s*$' -or
                $raw -match '^\s+void host_set_battle_mode\(') {
                # Keep as inline - trivial getter/setter
                $outLines += $raw
                continue
            }
            
            # Non-trivial one-liner: extract it
            # Replace `{ body }` with `;` in the signature
            $modifiedLine = $raw -replace '\s*\{.*\}\s*$', ';'
            $outLines += $modifiedLine
            # Extract the body
            $match = [regex]::Match($raw, '\{(.*)\}')
            if ($match.Success) {
                $bodyContent = $match.Groups[1].Value.Trim()
                $extractedBodies += @("    $bodyContent")
            }
            continue
        }
        
        if ($looksLikeMethod) {
            # This is an inline method body starting on this line
            # Output the line but with "{" replaced by ";"
            $modifiedLine = $raw -replace '\{\s*$', ';'
            # If there's trailing comment after {, handle differently
            if ($raw -match '\{\s*//') {
                $modifiedLine = $raw -replace '\{', ';' -replace ';//', ';//'
            }
            $outLines += $modifiedLine
            
            # Now extract the body by matching braces
            # First, find the { on this line
            $braceIdx = $raw.IndexOf('{')
            
            # The body starts after the first {
            $afterBrace = ""
            if ($braceIdx -ge 0 -and $braceIdx -lt $raw.Length - 1) {
                $afterBrace = $raw.Substring($braceIdx + 1)
            }
            
            # Track depth
            $bodyDepth = 1
            $bodyLines = @()
            if (![string]::IsNullOrEmpty($afterBrace)) {
                $bodyLines += "        $afterBrace"
            }
            
            # Count braces in the remaining part of this line
            $stripped = $afterBrace
            $stripped = [regex]::Replace($stripped, '"[^"]*"', '""')
            $stripped = [regex]::Replace($stripped, "'[^']*'", "''")
            foreach ($ch in $stripped.GetEnumerator()) {
                if ($ch -eq '{') { $bodyDepth++ }
                if ($ch -eq '}') { $bodyDepth-- }
            }
            
            if ($bodyDepth > 0) {
                $extractingBody = $true
            }
            continue
        }
    }
    
    # Check for continuation lines: if previous line started a multi-line signature
    # that hasn't encountered { yet, this is handled by the extractingBody flow
    
    # Regular line - output as-is
    $outLines += $raw
}

# Write stripped header
$outLines | Set-Content $headerOut -Encoding UTF8

# Write extracted bodies to temp file
$extractedBodies | ForEach-Object { $_ + "`n`n" } | Set-Content $cppAppend -Encoding UTF8

Write-Host "Header lines: $($outLines.Count)"
Write-Host "Extracted bodies: $($extractedBodies.Count)"
