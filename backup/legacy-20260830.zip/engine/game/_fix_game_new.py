#!/usr/bin/env python3
"""Fix corrupted method signatures in game_new.hpp and merge with game.hpp structure."""

import re

# Read both files
with open(r"E:\reSF2\engine\game\game_new.hpp", 'r', encoding='utf-8') as f:
    new_lines = f.readlines()

with open(r"E:\reSF2\engine\game\game.hpp", 'r', encoding='utf-8') as f:
    old_lines = f.readlines()

# Fix 1: Remove the corrupted duplicate signatures in game_new.hpp
# Pattern: `void foo() {void foo();` -> `void foo();`
# Also: `void foo(int x) {void foo(int x);` etc.
# More generally: `SIGNATURE {SIGNATURE;` -> `SIGNATURE;`
# The corrupted pattern is: after the {, the same signature is repeated with ;

fixed_lines = []
in_private = False
for line in new_lines:
    # Fix the corrupted pattern
    # Match: `type name(params) {type name(params);` 
    # The ) { is followed by same signature + ;
    fixed = line
    if ' {' in line and '();' in line:
        # Check if what's before { matches what's after { before ();
        before_brace = line[:line.index(' {')]
        # What's after {
        after_brace = line[line.index(' {') + 2:]
        # For simple patterns: void foo() {void foo();
        # Check if after_brace starts with before_brace + ;
        cleaned_before = before_brace.strip()
        cleaned_after = after_brace.strip()
        
        # Match: cleaned_before == cleaned_after (without ;)
        if cleaned_after.rstrip(';').strip() == cleaned_before:
            # Corrupted: replace with proper declaration
            fixed = f"{cleaned_before};\n"
    
    # Also handle patterns with override: void foo() override {void foo() override;
    if 'override' in line:
        m = re.match(r'^(\s*(?:virtual\s+)?(?:void|bool|int|float|uint32_t|uint64_t|size_t|double|char|const\s|std::|static\s|explicit\s|~\w+|resf2::)\s.*?)\s*\{\s*\1\s*;\s*\}\s*$', line)
        if m:
            sig = m.group(1).strip()
            fixed = f"    {sig};\n"
        
        # Simpler: just detect the { followed by same text pattern
        if ' {' in line and '();' in line:
            before = line[:line.index(' {')].strip()
            after = line[line.index(' {') + 2:].strip()
            # After might be like: "void foo() override;"
            if after.rstrip().rstrip(';').strip() == before:
                fixed = f"{before};\n"

    fixed_lines.append(fixed)

# Now verify we haven't lost any methods by comparing with old game.hpp
# Extract all method signatures from old file
old_sigs = set()
for line in old_lines:
    t = line.strip()
    if t and '{' in t and not t.startswith('//') and not t.startswith('#'):
        # Could be method signature
        brace_idx = t.index('{')
        before_brace = t[:brace_idx].strip()
        if before_brace and before_brace.endswith(')'):
            old_sigs.add(before_brace)

# Extract from new file  
new_sigs = set()
for line in fixed_lines:
    t = line.strip()
    if t.endswith(';') and not t.startswith('//') and not t.startswith('#'):
        before_semi = t.rstrip(';').strip()
        # Check it looks like a declaration (has return type or ~)
        if before_semi and (')' in before_semi):
            new_sigs.add(before_semi)

# Find what's missing
missing = old_sigs - new_sigs
extra = new_sigs - old_sigs

print(f"Old file signatures: {len(old_sigs)}")
print(f"New file signatures: {len(new_sigs)}")
print(f"Missing from new: {len(missing)}")
if missing:
    for m in sorted(missing)[:20]:
        print(f"  MISSING: {m}")
print(f"Extra in new: {len(extra)}")
if extra:
    for e in sorted(extra)[:10]:
        print(f"  EXTRA: {e}")

# Write fixed file
with open(r"E:\reSF2\engine\game\game_new.hpp", 'w', encoding='utf-8') as f:
    f.writelines(fixed_lines)

print(f"\nFixed file written: {len(fixed_lines)} lines")
