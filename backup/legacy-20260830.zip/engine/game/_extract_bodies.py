#!/usr/bin/env python3
"""
Extract inline method bodies from game_old.hpp and append them to game.cpp
as properly-scoped function definitions.
Also handle non-trivial inline methods that are still in game_new.hpp.
"""

import re
import os

GAME_OLD = r"E:\reSF2\engine\game\game_old.hpp"
GAME_CPP = r"E:\reSF2\engine\game\game.cpp"
GAME_NEW = r"E:\reSF2\engine\game\game_new.hpp"

# Read the old file
with open(GAME_OLD, 'r', encoding='utf-8') as f:
    old_lines = f.readlines()

# Read game.cpp to find already-implemented methods
with open(GAME_CPP, 'r', encoding='utf-8') as f:
    cpp_content = f.read()
    cpp_lines = f.readlines()

# Find methods already implemented in game.cpp
already_implemented = set()
for line in cpp_lines:
    t = line.strip()
    if 'Game::' in t or 'AnimationData::' in t:
        # Extract method name
        m = re.match(r'((?:void|bool|int|float|uint|size_t|double|char|const|std::)\s+)?((?:Game|AnimationData)::(\w+))\s*\(', t)
        if m:
            already_implemented.add(m.group(2))
            already_implemented.add(m.group(3))

for ai in sorted(already_implemented):
    print(f"Already implemented: {ai}")

# Now scan game_old.hpp for inline method bodies
# Strategy: find methods inside the class body (between line 93 and 3167)
# that have inline bodies

# We need to find the start and end of the Game class
class_start = -1
class_end = -1
for i, line in enumerate(old_lines):
    if 'class Game final' in line:
        class_start = i
    if class_start >= 0 and line.strip() == '};' and class_end < 0:
        class_end = i
        break

print(f"Class start: line {class_start+1}, Class end: line {class_end+1}")

# Extract method bodies using brace counting
# We track depth to find matching } for each {

# Simplified approach: find lines inside the class body
# that start a method (have a signature-looking text followed by { on same line)
# then track braces to find the matching }

# Also handle methods where { is on the next line

i = class_start
depth = 0
method_bodies = []  # list of (signature_lines, body_lines)

while i <= class_end:
    raw = old_lines[i]
    
    # Skip non-method lines (comments, preprocessor, member variables)
    # We're looking for: return_type method_name(params) {
    # or: type method_name(params) const {
    # or: type method_name(params) override {
    # etc.
    
    line = raw.rstrip('\n').rstrip('\r')
    trimmed = line.strip()
    
    # Check if this line starts with a method return type pattern
    # AND ends with { (or has { later in the line)
    # We need to ignore: struct/class/enum definitions, if/for/while/switch
    
    is_method = False
    brace_pos = -1
    
    # Remove string literals for detection
    stripped = re.sub(r'"[^"]*"', '', line)
    stripped = re.sub(r"'[^']*'", '', stripped)
    # Remove block comments
    stripped = re.sub(r'/\*.*?\*/', '', stripped)
    
    if '{' in stripped:
        brace_pos = stripped.index('{')
        before_brace = stripped[:brace_pos].strip()
        
        # Check if this looks like a method signature
        # Contructors: ~ClassName( or ClassName(
        if re.match(r'^~?\w[\w:]*\s*\(', before_brace):
            is_method = True
        # Return type pattern
        elif re.match(r'^(void|bool|int|float|double|char|uint\d*_t|int\d+_t|size_t|long|short|auto|const\s|std::|static\s|virtual\s|explicit\s|inline\s)', before_brace):
            is_method = True
        
        # Exclude control flow
        if is_method and re.match(r'^(if|for|while|switch|else|catch|do)\b', before_brace):
            is_method = False
        # Exclude class/struct/enum/namespace/open brace of class
        if re.match(r'^(class|struct|enum|namespace)\b', before_brace):
            is_method = False
    
    if is_method:
        # This is a method with inline body
        # Collect the signature (may span multiple lines before {)
        # For now, we assume { is on the same line as the end of the sig
        
        # Extract what's before the {
        sig_lines = []
        # Find the actual start of this method signature (may span multiple lines)
        # Look backward from i to find where the return type starts
        sig_start = i
        while sig_start > class_start:
            prev_line = old_lines[sig_start - 1]
            pt = prev_line.strip()
            # If previous line is a comment, preprocessor, empty, or member var, stop
            if pt.startswith('//') or pt.startswith('#') or pt == '' or pt == 'private:' or pt == 'public:' or pt == 'protected:':
                break
            # If previous line ends with ; or }, it's likely previous method
            if prev_line.rstrip('\n').rstrip('\r').rstrip().endswith(';') or prev_line.rstrip('\n').rstrip('\r').rstrip().endswith('}'):
                break
            sig_start -= 1
        
        # Collect signature lines (the lines before {)
        sig_text = ''
        for j in range(sig_start, i + 1):
            l = old_lines[j].rstrip('\n').rstrip('\r')
            sig_text += l + '\n'
        
        # Remove trailing { from last line for pure sig
        sig_pure = sig_text.rstrip()
        # Find the last { and remove everything from it
        last_brace = sig_pure.rfind('{')
        if last_brace >= 0:
            sig_pure = sig_pure[:last_brace].strip()
        
        # Now collect the body
        after_brace_idx = line.index('{') + 1 if '{' in line else len(line)
        # Content after the { on this line
        after_brace = line[brace_pos + 1:] if brace_pos + 1 < len(line) else ''
        
        # Track brace depth
        body_depth = 1
        body_lines = []
        if after_brace.strip():
            body_lines.append(after_brace)
            for c in after_brace:
                if c == '{': body_depth += 1
                if c == '}': body_depth -= 1
        
        j = i + 1
        while j <= class_end and body_depth > 0:
            bl = old_lines[j]
            body_lines.append(bl.rstrip('\n').rstrip('\r'))
            # Count braces (ignoring strings and comments)
            bclean = re.sub(r'"[^"]*"', '', bl)
            bclean = re.sub(r"'[^']*'", '', bclean)
            bclean = re.sub(r'//.*$', '', bclean)
            for c in bclean:
                if c == '{': body_depth += 1
                if c == '}': body_depth -= 1
            j += 1
        
        # Remove last line's trailing } (the closing brace of the method)
        if body_lines:
            last_body = body_lines[-1]
            # Find the } that closes the body
            close_pos = last_body.rfind('}')
            if close_pos >= 0:
                last_body = last_body[:close_pos].rstrip()
                if last_body:
                    body_lines[-1] = last_body
                else:
                    body_lines.pop()
        
        # Store the method
        method_bodies.append({
            'sig': sig_pure,
            'sig_start': sig_start,
            'body': body_lines,
            'start_line': i
        })
        
        # Skip past the method body
        i = j - 1  # -1 because loop increments
        
        continue
    
    i += 1

print(f"\nFound {len(method_bodies)} inline method bodies in game_old.hpp")

# Convert to Game:: prefixed implementations
# For methods that are inside the Game class but don't use scope resolution,
# we need to add Game:: prefix
new_implementations = []
for method in method_bodies:
    sig = method['sig']
    
    # Extract the method name from the signature
    # Pattern: return_type method_name(params) or return_type method_name(params) const
    # We need to rewrite as return_type Game::method_name(params) or similar
    
    # Check if sig already has a scope
    if '::' in sig:
        # Already scoped (shouldn't happen as these are class members)
        new_sig = sig
    else:
        # Add Game:: scope
        # Find the method name: it's the token before the first (
        m = re.match(r'^((?:virtual\s+|static\s+)?(?:\w[\w\s:*&]*\s+)?)(\w[\w:~]*)\s*(\()', sig)
        if m:
            prefix = m.group(1).strip()  # return type
            name = m.group(2)            # method name
            rest = sig[m.end(2):]        # everything from ( onwards
            if prefix:
                new_sig = f"{prefix} Game::{name}{rest}"
            else:
                # Constructor/destructor or operator
                new_sig = f"Game::{name}{rest}"
        else:
            # Fallback: just check if it starts with ~ or word(
            m2 = re.match(r'^([\w:~]+)\s*(\()', sig)
            if m2:
                name = m2.group(1)
                rest = sig[m2.end(1):]
                new_sig = f"Game::{name}{rest}"
            else:
                # Keep as-is (might be operator)
                new_sig = sig
    
    # Filter out methods already in game.cpp
    name_match = re.search(r'(?:Game|AnimationData)::(\w+)', new_sig)
    if name_match:
        method_name = name_match.group(1)
        if method_name in already_implemented:
            print(f"  SKIP (already in game.cpp): {method_name}")
            continue
    
    methods_to_remove = {'update_animation', 'play_animation', 'host_update_gameplay'}
    if method_name in methods_to_remove:
        print(f"  SKIP (already in game.cpp): {method_name}")
        continue
    
    # Build the full implementation
    impl = f"\n{new_sig} {{\n"
    for bl in method['body']:
        impl += f"    {bl}\n"
    impl += "}\n"
    
    new_implementations.append(impl)
    method_name = name_match.group(1) if name_match else "?"

# Append to game.cpp
if new_implementations:
    with open(GAME_CPP, 'a', encoding='utf-8') as f:
        f.write("\n\n// ======== Extracted inline method bodies from game.hpp ========\n")
        for impl in new_implementations:
            f.write(impl)
    
    print(f"\nAppended {len(new_implementations)} method implementations to game.cpp")
else:
    print("\nNo new methods to append")

print(f"\ngame.cpp line count: {len(open(GAME_CPP).readlines())}")
