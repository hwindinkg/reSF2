#!/usr/bin/env python3
"""Extract inline method bodies from game_old.hpp, add Game:: prefix, append to game.cpp."""

import re

OLD = r"E:\reSF2\engine\game\game_old.hpp"
CPP = r"E:\reSF2\engine\game\game.cpp"

with open(OLD, 'r', encoding='utf-8') as f:
    text = f.read()

# Find the Game class body - between the first { after class Game... and }; 
m = re.search(r'class Game final[^{]*\{', text)
if not m:
    print("ERROR: Cannot find Game class start")
    exit(1)

class_body_start = m.end()  # position after the opening { of the class
# Now find the matching } at class level
depth = 1
pos = class_body_start
while depth > 0 and pos < len(text):
    c = text[pos]
    if c == '{':
        depth += 1
    elif c == '}':
        depth -= 1
    pos += 1

class_body_end = pos - 1  # position of the final }
class_text = text[class_body_start:class_body_end]

# Now find methods within the class body
# A method starts with a return type pattern and has matching { }
# We identify method starts by looking for lines inside the class
# that begin with a return-type pattern and have { later in the line

lines = class_text.split('\n')
# Track the line number offset from the start of class_text
# Method extraction: find lines ending with { (or containing {) that look like method sigs

# Already in game.cpp - don't duplicate
in_cpp = {'update_animation', 'play_animation', 'host_update_gameplay'}
# Also AnimationData methods are in game.cpp already

# Helper to strip strings and comments for brace counting
def clean_for_brace_count(s):
    result = ''
    in_str = False
    in_ch = False
    in_block = False
    i = 0
    while i < len(s):
        c = s[i]
        n = s[i+1] if i+1 < len(s) else ''
        if in_block:
            if c == '*' and n == '/':
                in_block = False
                i += 2
                continue
            i += 1
            continue
        if c == '"' and not in_ch:
            in_str = not in_str
            i += 1
            continue
        if c == "'" and not in_str:
            in_ch = not in_ch
            i += 1
            continue
        if in_str or in_ch:
            i += 1
            continue
        if c == '/' and n == '/':
            break  # rest is comment
        if c == '/' and n == '*':
            in_block = True
            i += 2
            continue
        result += c
        i += 1
    return result

# Find all method bodies
# Strategy: iterate through lines, when we see a method sig line ending with {,
# collect the body until matching }

def is_method_sig_line(clean_line):
    """Check if stripped+cleaned line starts a method inline body."""
    if '{' not in clean_line:
        return False
    brace_pos = clean_line.index('{')
    before = clean_line[:brace_pos].strip()
    if not before:
        return False
    # Must end with ) possibly followed by const/override/noexcept/&
    sig_check = re.sub(r'\b(const|override|noexcept|throw\s*\([^)]*\)|&\s*)\s*$', '', before).strip()
    if not sig_check.endswith(')'):
        return False
    first_word = before.split()[0] if before.split() else ''
    if first_word in {'if', 'for', 'while', 'switch', 'else', 'catch', 'try', 'do'}:
        return False
    if first_word in {'struct', 'class', 'enum', 'namespace'}:
        return False
    # Should start with return-type-like pattern or be a constructor
    if re.match(r'^(void|bool|int|float|double|char|uint\d*_t|int\d+_t|size_t|long|short|auto|const\b|std::|static\b|virtual\b|explicit\b|inline\b|~\w)', before):
        return True
    if re.match(r'^[\w:~]+\s*\(', before):
        return True
    return False

# Process
methods = []
i = 0
while i < len(lines):
    raw = lines[i]
    clean = clean_for_brace_count(raw)
    
    if is_method_sig_line(clean):
        # Find the { position
        brace_pos = clean.index('{')
        
        # Collect signature (may span multiple lines before this line)
        sig_parts = []
        sig_start = i
        # Include lines before i that are part of the sig
        # A multi-line sig looks like: return_type\nmethod_name(\n  params\n) {
        # We need to capture everything from the return type to the {
        
        # The simplest approach: the sig is everything on this line before {
        sig_text = raw[:brace_pos + (len(raw) - len(clean))].strip()
        
        # Check if previous line was a continuation (didn't end with ; or })
        # Include previous lines if they don't end with semicolon/brace
        j = i - 1
        while j >= 0:
            prev = lines[j].strip()
            if not prev or prev.startswith('//') or prev.startswith('/*') or prev.endswith('*/'):
                j -= 1
                continue
            if prev.endswith(';') or prev.endswith('{') or prev.endswith('}') or prev == 'public:' or prev == 'private:' or prev == 'protected:':
                break
            # This line is part of the sig
            sig_text = prev + ' ' + sig_text
            sig_start = j
            j -= 1
        
        # Extract the name for dedup
        name_match = re.search(r'\b(\w+)\s*\(', sig_text)
        method_name = name_match.group(1) if name_match else 'unknown'
        
        # Collect body
        body_lines = []
        after_brace_text = raw[brace_pos + 1 + (len(raw) - len(clean)):] if brace_pos + 1 + (len(raw) - len(clean)) < len(raw) else ''
        
        body_depth = 1
        if after_brace_text.strip():
            body_lines.append(after_brace_text)
            for c in clean_for_brace_count(after_brace_text):
                if c == '{': body_depth += 1
                if c == '}': body_depth -= 1
        
        li = i + 1
        while li < len(lines) and body_depth > 0:
            bl = lines[li]
            body_lines.append(bl)
            bclean = clean_for_brace_count(bl)
            for c in bclean:
                if c == '{': body_depth += 1
                if c == '}': body_depth -= 1
            li += 1
        
        # Remove trailing } from last body line
        if body_lines:
            last = body_lines[-1]
            close_pos = last.rfind('}')
            if close_pos >= 0:
                last = last[:close_pos].rstrip()
                if last:
                    body_lines[-1] = last
                else:
                    body_lines.pop()
        
        # Skip if already in game.cpp (AnimationData methods or Game methods already there)
        if method_name in in_cpp or 'AnimationData::' in sig_text or 'AnimationData' in sig_text:
            print(f"  SKIP (already in cpp): {method_name}")
        else:
            methods.append({
                'name': method_name,
                'sig': sig_text,
                'body': body_lines
            })
        
        i = li - 1
    
    i += 1

print(f"Found {len(methods)} methods to extract")

# Generate Game:: prefixed implementations
# Determine return type and method name from signature
impls = []
for m in methods:
    sig = m['sig']
    
    # Check if sig already has scope resolution
    if '::' in sig:
        # Could be something like operator or already scoped
        scoped_sig = sig
    else:
        # Add Game:: scope
        # Pattern: "return_type method_name(params..." -> "return_type Game::method_name(params..."
        # Remove trailing whitespace
        sig_clean = sig.strip()
        
        # Try to parse the signature
        # Cases:
        # 1. "void foo(int x) const" -> "void Game::foo(int x) const"
        # 2. "~Game()" -> "Game::~Game()"
        # 3. "operator bool() const" -> "Game::operator bool() const"
        # 4. "int& mutable_foo()" -> "int& Game::mutable_foo()"
        
        # Find the function name (word before first parenthesis that isn't a type keyword)
        # Use regex: optional return type, then name, then (
        # return_type can be: void, bool, int, std::..., etc. followed by name(
        
        # Strategy: find the first ( and work backwards to find the name
        paren_pos = sig.find('(')
        if paren_pos >= 0:
            before_paren = sig_clean[:paren_pos].strip()
            
            # The name is the last word before (
            words = before_paren.split()
            if words:
                last_word = words[-1]
                # last_word could be: method_name, operator, ~MethodName
                # Remove trailing &/*/const/etc
                name_part = last_word.rstrip('&*')
                
                # return_type is everything except the last word
                ret_type = ' '.join(words[:-1])
                
                # rest of signature is from ( onwards
                rest = sig_clean[paren_pos:]
                
                if ret_type:
                    scoped_sig = f"{ret_type} Game::{name_part}{rest}"
                else:
                    # Constructor/destructor - just add Game::
                    scoped_sig = f"Game::{name_part}{rest}"
        else:
            scoped_sig = sig_clean
    
    # Build the implementation
    body_text = '\n'.join(m['body'])
    # Remove trailing spaces
    body_text = '\n'.join(l.rstrip() for l in body_text.split('\n'))
    
    impl_text = f"\n{scoped_sig} {{\n{body_text}\n}}\n"
    impls.append(impl_text)

# Read current game.cpp
with open(CPP, 'r', encoding='utf-8') as f:
    cpp_text = f.read()

# Append implementations before the closing namespace brace
# Find the last } // namespace resf2::game
ns_close = cpp_text.rfind('} // namespace resf2::game')
if ns_close >= 0:
    new_cpp = cpp_text[:ns_close] + ''.join(impls) + cpp_text[ns_close:]
else:
    new_cpp = cpp_text + "\n\nnamespace resf2::game {\n" + ''.join(impls) + "\n} // namespace resf2::game\n"

with open(CPP, 'w', encoding='utf-8') as f:
    f.write(new_cpp)

print(f"Appended {len(impls)} method implementations to game.cpp")

# Count lines
with open(CPP, 'r', encoding='utf-8') as f:
    new_lines = f.readlines()
print(f"game.cpp now has {len(new_lines)} lines")

# Show what was added
print("\nMethods added:")
for m in methods:
    print(f"  {m['name']}")
