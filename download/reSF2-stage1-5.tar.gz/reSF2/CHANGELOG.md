# Changelog

All notable changes to reSF2 are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project
aims for [Semantic Versioning](https://semver.org/) once v1.0 is reached.

Stages are the high-level units of progress (see `TODO.md`).

## [Unreleased]

### Stage 1 — APK investigation & project scaffolding  (2026-07-09)

#### Investigated
- Downloaded and verified Shadow Fight 2 v1.9.21 APK
  (`sha256=9258146bb87e7d1010ebbd6cc9f7bc9f00f1f2ff61ae4a73cd29003b072f5143`,
  94 736 412 bytes, build date 2016-06-09).
- Decoded AndroidManifest.xml, apktool.yml, both DEX files, all native
  libraries and the full asset tree.
- Determined that the game runs on **Marmalade SDK v8.2.1** (formerly
  Airplay SDK), single ABI `armeabi-v7a`, OpenGL ES 2.0, landscape.
- Identified that the actual game logic is shipped inside the
  LZMA-compressed `assets/ShadowFight2.s3e` binary (magic `XE3U`,
  2 858 937 → 8 689 357 bytes), not inside a Java class or a regular
  `lib*.so` next to `libs3e_android.so`.
- Mapped 30 native libraries under `lib/armeabi-v7a/`, classified by role
  (Marmalade runtime, SmartFox2X client, FFmpeg 2.x family, controller
  input, haptics, 23 `s3e*` platform extensions for ads / IAP / analytics).
- Mapped ~10 300 Java classes; only `com.nekki.shadowfight.Main` is the
  entry activity. Everything else is third-party ad/IAP/analytics SDK plus
  Marmalade's `com.ideaworks3d.marmalade.*` glue layer.
- Catalogued 1 866 asset files (PNG 1 333, plist 148, ATF-style 110,
  XML 77, WAV 76, JPG 70, FNT 16, JSON 11, MP3 5, DTRZ .dz 2, MP4 1, INI 1).
- Decoded the ATF-style files: they are zlib-compressed custom blobs whose
  payload is weapon-pair combat tactics (e.g. `batons_claws.atf` describes
  the batons-vs-claws exchange table). Not Adobe Texture Format.
- Decoded the DTRZ `.dz` files: custom archive format (magic `DTRZ`)
  holding multiple XML data files (animation defs, file manifest).
- Parsed `assets/settings.xml`: this is the master manifest listing every
  gameplay XML (achievements, quests, perks, models, localizations, raid
  stages, tactic settings, user defaults, etc.).

#### Recovered
- Engine identity and version: **Marmalade v8.2.1 build 465988**.
- The shape of the S3E binary container (LZMA1 wrapper + `XE3U` sectioned
  payload with embedded Marmalade config text + ARM `.text` segment).
- JNI registration model: `libs3e_android.so` exports only `JNI_OnLoad` /
  `JNI_OnUnLoad` — all native methods are registered dynamically via
  `RegisterNatives()`, so we must trace `JNI_OnLoad` to recover the
  Java↔native symbol map (deferred to Stage 2).
- Networking stack: SmartFoxServer 2X C++ API (`Sfs2X::*` namespaces in
  `libsmartfox.so`, built on `boost::asio` TCP/UDP, with `ConfigLoader`,
  `BitSwarmClient`, `LagMonitor`, packet encrypter).
- Video stack: FFmpeg 2.x (`libavcodec-55`, `libavformat-55`, `libavutil-52`,
  `libswscale-2`) exposed via `libs3eFfmpeg.so`.
- Asset layout: two asset scales (`1536/` and `768/`), 50+ battle locations,
  110 weapon-vs-weapon tactics files, 12 localizations (chn, chn_tr, eng,
  fra, ger, ita, jpn, kor, por, rus, spa, tur).

#### Implemented
- Repository skeleton: `engine/{runtime,renderer,physics,animation,audio,
  network,platform,tools,reverse}`, `docs/`, `tests/`, `assets/`,
  `scripts/`.
- `README.md`, `CHANGELOG.md`, `TODO.md`, `.gitignore`.
- Top-level `CMakeLists.txt` skeleton (C++20, no targets yet — first
  real targets land in Stage 2).
- Stage 1 documentation set in `docs/`:
  - `00_stage1_summary.md`
  - `01_apk_structure.md`
  - `02_native_libraries.md`
  - `03_java_layer.md`
  - `04_assets_inventory.md`
  - `05_resource_formats.md`
  - `06_engine_marmalade.md`
  - `07_jni_and_loader.md`
  - `08_reverse_engineering_log.md`

#### Tests
- No code yet → no tests. Stage 2 will introduce the first unit tests
  for the LZMA1 + `XE3U` container parser.

#### Files changed
- `README.md`, `CHANGELOG.md`, `TODO.md`, `.gitignore`,
  `CMakeLists.txt`, `engine/.keep`, `tests/.keep`, `assets/.keep`,
  `scripts/.keep`, `docs/00_stage1_summary.md`,
  `docs/01_apk_structure.md`, `docs/02_native_libraries.md`,
  `docs/03_java_layer.md`, `docs/04_assets_inventory.md`,
  `docs/05_resource_formats.md`, `docs/06_engine_marmalade.md`,
  `docs/07_jni_and_loader.md`, `docs/08_reverse_engineering_log.md`.

#### Notes
- User-supplied GitHub PAT was exposed in the originating chat. It was
  **not** used during this stage. The user must revoke it and reconfigure
  auth locally before pushing this commit.

## Stage 2 — `.s3e` binary & JNI map  (2026-07-09)

### Investigated
- Decompressed `ShadowFight2.s3e` (LZMA1 legacy, 2 858 937 -> 8 689 357 B)
  and mapped the inner `XE3U` container header (76 bytes / 19 u32 fields).
- Located and documented three payload sections:
  - Embedded Marmalade config text (offset 0x4c, length 5 333 B) — the
    global `s3e.icf` with the runtime extension list at the end.
  - Import-name table (offset 0x1521, ~10 KB) — 346 valid C-identifier
    function names that the game imports from the Marmalade loader
    (117 `s3e*`, 210 `gl*`, 19 other).
  - Relocation table (offset 0x2bbf, ~266 KB) — GOT-reference array
    pointing to slots at vaddr 0x007b8000. Full layout deferred to
    Stage 4 (not needed for clean-room).
- Located 17 GLSL shader sources in the `.rodata` region (offset
  0x768ee9..0x76b000). All use GLES2 syntax; many use Cocos2d-x
  naming (`CC_Texture0`, `v_fragmentColor`, `v_texCoord`).
- Disassembled `JNI_OnLoad` (file offset 0x3c770, ARM mode) via
  Python + Capstone 5.0.7 — system `objdump` lacks ARM support.
  `JNI_OnLoad` is a thin shim: stores `JavaVM*`, clears a flag, calls
  `_s3eAndroidInit` at 0x3c698, returns `JNI_VERSION_1_4`.
- Recovered ~110 Java native method names + 24 JNI signatures +
  14 Java class references from string analysis of
  `libs3e_android.so` `.rodata`. Categories: lifecycle, input,
  audio, video, haptics, filesystem, device info.

### Recovered
- The complete Marmalade SDK API surface the game uses (346 imports).
  This is the contract reSF2's runtime must provide.
- All 17 GLSL shaders the game uses for sprite rendering, alpha-test,
  masking, and color-fill.
- The Java↔native dispatch shape: one `JNI_OnLoad` registers ~110
  native methods on 4 Marmalade Java classes (`LoaderThread`,
  `LoaderView`, `LoaderKeyboard`, `LoaderThread$MediaPlayerManager`).

### Implemented
- `engine/reverse/s3e_container.{hpp,cpp}` — read-only C++23 parser
  for the `XE3U` container. Validates magic, parses the 76-byte
  header, exposes the embedded config text, and extracts the
  import-name table. Uses `std::expected` + `std::span` for borrow
  safety; no exceptions in the parser path.
- `engine/reverse/CMakeLists.txt` — defines `libresf2_reverse.a`
  static library target.
- `tests/test_s3e_container.cpp` — 24 unit tests (synthetic data +
  real-file fixture). Covers: empty/too-small/bad-magic rejection,
  minimal valid file parse, real `ShadowFight2.bin` parse with
  spot-checks on header fields, config text, and import names.
- `engine/reverse/s3e_imports.txt` — full 346-entry import list.
- `engine/reverse/s3e_shaders.txt` — full 17-shader source dump.
- `docs/09_s3e_binary_format.md` — `XE3U` container spec.
- `docs/10_jni_registration_map.md` — JNI surface map.

### Tests
- `test_s3e_container`: 24/24 passing.
- CMake build (C++23, g++ 14.2.0): `cmake -S . -B build-cmake`,
  `cmake --build build-cmake`, `ctest --test-dir build-cmake` →
  `100% tests passed, 0 tests failed out of 1`.
- Standalone build: `g++ -std=c++23 -Iengine tests/test_s3e_container.cpp
  engine/reverse/s3e_container.cpp -o build/test_s3e_container` → passes.

### Files changed
- `CMakeLists.txt` — bumped to C++23, version 0.0.2.
- `engine/CMakeLists.txt` — updated comment (Stage 2 introduces first
  real target).
- `engine/reverse/CMakeLists.txt` — new, defines `libresf2_reverse`.
- `engine/reverse/s3e_container.hpp` — new, public parser API.
- `engine/reverse/s3e_container.cpp` — new, parser implementation.
- `engine/reverse/s3e_imports.txt` — new, 346 import names.
- `engine/reverse/s3e_shaders.txt` — new, 17 GLSL shaders.
- `tests/CMakeLists.txt` — defines `test_s3e_container`.
- `tests/test_s3e_container.cpp` — new, 24 tests.
- `docs/09_s3e_binary_format.md` — new.
- `docs/10_jni_registration_map.md` — new.
- `.gitignore` — added `tests/fixtures/`, `ShadowFight2.bin`.

### Notes
- The original `ShadowFight2.bin` (8.69 MB decompressed S3E payload)
  is placed under `tests/fixtures/` locally for the real-file test
  but is `.gitignored` — the repo never ships original game binaries.
- CMake 4.3.4 was installed via `pip install cmake` (no sudo needed).
  Capstone 5.0.7 was installed via `pip install capstone` for ARM
  disassembly in the RE scripts.
- Stage 2.6 (exact `JNINativeMethod[]` array offset) is deferred —
  requires Ghidra or IDA. Not needed for clean-room reimplementation.

## Stage 3 — Engine architecture recovery  (2026-07-09)

### Investigated
- Mined 9 330 unique C++ identifiers from `.s3e` `.rodata` (excluding
  the import table region 0x1521–0x2bbf). 85 game-side classes
  recovered with at least one `Class::method` reference; 250+ methods
  catalogued in `engine/reverse/s3e_classes.txt`.
- Identified the rendering layer as **Cocos2d-x 2.x-style** (236 refs
  to `cocos2d`, plus `CCNode`, `CCSprite`, `CCDirector`, `CCScene`,
  `CCLayer`, `CCAction`, `CCAnimation`, `CCAnimate`, `CCSpriteFrame`,
  `CCSpriteBatchNode`, `CCTexture2D`, `CCTextureCache`,
  `CCRenderTexture`, `CCScrollView`, `CCParticle`, `CCLabelTTF`,
  `CCLabelBMFont`, `CCTouch`, `CCEGLView`). Nekki wrote their own
  thin layer that mimics the Cocos2d-x 2.x API — this is NOT the
  official Cocos2d-x Marmalade port.
- Identified XML parsers: **pugixml** (primary, 4 refs) +
  **tinyxml** (secondary, 15 refs). Both MIT-licensed; reSF2 will
  vendor both unchanged.
- Identified save system: `assets/localSettings.bin`, AES-encrypted
  (strings `error during encryption`, `error during decryption`,
  `AES128-CBC-SHA`, `AES256-CBC-SHA`). `UserDefault.xml` stores
  only non-sensitive UI settings.
- Confirmed physics is **fully custom** — no Box2D / Chipmunk /
  Bullet / ODE / Tokamak references. Collision is direct
  rectangle-vs-rectangle testing driven by `.atf` tactics data.
- Confirmed networking uses SmartFoxServer 2X for raids: `BitSwarmClient`,
  `UDPManager`, `TCPSocketLayer`, `UDPSocketLayer`, `SFSProtocolCodec`,
  `DefaultPacketEncrypter`, `SystemController`, `ExtensionController`,
  `LagMonitor`, `ConfigLoader`, `LoginRequest`.
- Identified main loop as **single-threaded, variable-step**, driven
  by `s3eTimerGetMs()` with `dt` clamped to 200 ms (Cocos2d-x 2.x
  convention). Only 1 import of `s3eThreadCreate` — no worker thread
  pool. Audio runs on a separate Marmalade-managed thread.
- Identified camera: 2D orthographic, follow-the-player scroll,
  shake on heavy hits, zoom on critical moments.

### Recovered
- Game-side class inventory: 85 classes organised into 7 categories
  (orchestration, battle, models, quests, items, UI, multiplayer,
  ads/IAP). See `engine/reverse/s3e_classes.txt`.
- Layered architecture: game logic → Cocos2d-x 2.x-style layer →
  pugixml/tinyxml → SmartFox2X → Marmalade SDK → Android.
- Main loop structure: init → loop{yield, poll, update, render,
  present} → shutdown. Detailed in `docs/12_main_loop.md`.
- Per-subsystem update order (10 phases, from input to audio).
- Frame timing budget: 15 ms / frame at 60 FPS target.
- Pause/resume semantics: `nativePause` flag, audio thread stays
  alive, network socket kept open with LagMonitor keep-alive.
- Fixed-step vs variable-step: **variable-step** confirmed (`.atf`
  tactics store frame windows in milliseconds, not frame counts).

### Implemented
- `docs/11_engine_architecture.md` — full recovered architecture
  with class inventory, layered diagram, and reSF2 target architecture.
- `docs/12_main_loop.md` — main loop pseudocode, update order,
  frame timing budget, pause/resume, fixed-step decision.
- `engine/reverse/s3e_classes.txt` — 85 game classes with method
  lists.

### Files changed
- `docs/11_engine_architecture.md` — new.
- `docs/12_main_loop.md` — new.
- `docs/README.md` — updated Stage 2/3 sections.
- `engine/reverse/s3e_classes.txt` — new, 85 classes.
- `TODO.md` — Stage 3 marked complete.
- `CHANGELOG.md` — this entry.

### Notes
- Cocos2d-x 2.x API surface is public and MIT-licensed — reSF2 can
  re-implement `CCNode`/`CCSprite`/`CCDirector`/etc cleanly without
  copying any Nekki code. This significantly de-risks Stage 7.2
  (renderer).
- The `localSettings.bin` AES key is not yet recovered — needs a
  runtime trace or known-plaintext attack on a real save file
  (Stage 7.8 task).
- Stage 4 (game object & skeletal format recovery) is next: full
  `.dz` DTRZ archive unpack + `moves.xml` schema + `.atf` tactics
  byte layout, plus a C++20 reader for each.


## Stage 4 — Resource format recovery  (2026-07-09)

### Investigated
- **`.dz` (DTRZ archive)**: Mapped the outer container: 9-byte header
  (DTRZ + u16 + u16 + u8), filename list (224 entries in files.dz,
  1112 in animations.dz), metadata table (6 bytes per entry: u16 id +
  u8 0 + u16 0xffff sentinel + u8 parent_dir_id), offset/size table
  (16 bytes per file: 4 x u32 LE with format `(flags<<24) | u24_value`,
  constant `0x04` flag in field 4 = compression_type=zlib).
- **`.dz` payload encryption**: Discovered that file payloads are
  **XOR-encrypted**, NOT standard zlib. Despite `78 da` / `78 9c` /
  `78 5e` byte pairs (which look like zlib magic), `zlib.decompress`
  fails on all of them. Known-plaintext attack on file 0 of files.dz
  (assuming `<?xml version="1.0"` start) yielded a 19-byte key fragment
  `e9 3c dd 04 90 25 ed 5f ae 89 c9 b8 d2 b2 aa 3d 55 5c f5` but the
  key doesn't repeat cyclically — it's either a longer key or a stream
  cipher (RC4-like). Searched .s3e for the fragment: not found. Tried
  RC4 with 14 common seeds: no match. Tried 8-bit LCG brute force:
  no match. Key recovery deferred to Stage 4.x (requires disassembly
  of the .s3e derbh reader near string offset 0x797f39).
- **`.atf` (tactics blob)**: zlib decompression works cleanly on all
  4 sample files. Mapped the decompressed structure: 4-byte version
  (always 1) + null-terminated weapon A name + null-terminated weapon
  B name + binary tactics data. Binary section starts with u32
  (record count? byte count?) + u16 constant 858 (stride?) + u16
  (varies) + long sequence of small u8 values (4-28 range, likely
  move indices). Full byte layout deferred.
- **`.plist` (Cocos2d-x TexturePacker v2 atlas)**: Plain XML,
  fully documented. 148 files, all format v2. Fields: `frame`,
  `offset`, `rotated`, `sourceColorRect`, `sourceSize` + metadata
  block with `format=2`, `realTextureFileName`, `size`,
  `smartupdate`, `textureFileName`.
- **`.fnt` (AngelCode BMFont)**: Plain text, fully documented. 16
  files. Standard `info` / `common` / `page` / `chars` / `char` /
  `kernings` / `kerning` lines.
- **`.json` (CocoGUI UI scene)**: Plain JSON, fully documented.
  11 files under cocoGUI/raids/. CocoGUI v3.10.0.0. Widget tree with
  `ctype` field identifying widget type (ButtonObjectData,
  ImageViewObjectData, TextObjectData, ListViewObjectData, etc.).
- **On-disk XMLs**: `settings.xml` (master manifest, 119 lines),
  `devices.xml` (device capability profile, 10 KB),
  `versionController.xml` (version=1.9.21),
  `obbSettings.xml` (ObbVersion=1000062, UseObb=0).

### Recovered
- The DTRZ archive outer format (header + filename list + metadata
  table + offset/size table) — everything except the encrypted
  payload.
- The `.atf` header format (version + 2 weapon names + binary
  section with constant 858 stride).
- All on-disk asset formats (`.plist`, `.fnt`, `.json`, `.xml`,
  `.png`, `.wav`, `.mp3`, `.mp4`, `.ttf`, `.icf`).
- The full list of 110 `.atf` tactics files and the 17 unique weapon
  IDs they cover.
- Confirmation that the game's XMLs (156 files including the all-
  important `moves.xml` + `moves.xsd` schema) live INSIDE `files.dz`,
  not on disk.

### Implemented
- `docs/13_animation_format.md` — `.dz` DTRZ archive format + .bin
  animation blob placeholder.
- `docs/14_tactics_format.md` — `.atf` tactics format (header + binary
  section partial).
- `docs/15_resource_formats_final.md` — final inventory of all asset
  formats with status and reSF2 loader plan.

### Files changed
- `docs/13_animation_format.md` — new.
- `docs/14_tactics_format.md` — new.
- `docs/15_resource_formats_final.md` — new.
- `docs/README.md` — updated Stage 4 section.
- `TODO.md` — Stage 4 marked complete (with `.dz`/`.atf`/`.bin`
  deferred sub-tasks noted).
- `CHANGELOG.md` — this entry.

### Tests
- No new code in Stage 4 (documentation only). Stage 2 tests still
  pass: 24/24 via cmake/ctest.
- Stage 5 will implement loaders for `.plist`, `.fnt`, `.atf`, `.dz`
  (with `dz` loader blocked on encryption key).

### Notes
- The `.dz` encryption is the single biggest blocker for Stage 7.3
  (skeletal animation) and Stage 7.7 (battle logic). Both need access
  to `animations.dz` (`.bin` blobs) and `files.dz` (`moves.xml`,
  `tacticSettings.xml`, model XMLs).
- Milestones M1 (window opens) and M2 (main menu visible) do NOT
  need `.dz` extraction — they use only on-disk assets (`.png`,
  `.plist`, `.fnt`, `.json`).
- Milestone M3 (playable fight) DOES need `.dz` extraction.
- Workaround for M3: write a frida script that hooks
  `s3eCompressionDecomp*` on a real device and dumps the decrypted
  XMLs / `.bin`s to disk. The user can then provide these for reSF2
  to consume directly. This is documented in `13_animation_format.md`.


## Stage 5 — Asset loaders  (2026-07-09)

### Investigated
- Downloaded the official Marmalade `dzip.exe` (v8.6.0, 252 KB PE32)
  provided by the user. Reverse-engineered it via Capstone x86
  disassembly. Confirmed:
  - Contains zlib 1.1.3, bzip2 1.0.3, LZMA, and Marmalade's proprietary
    "DZ" coder (arithmetic/range coding with bit-packing via
    `shl`/`shr`/`xor` against a CRC32 table at VA 0x43a088).
  - 5 compression types: `dz`, `zlib`, `bzip`, `zero`, `copy`.
  - Type byte 0x04 in our .dz file = DZ compression (NOT zlib).
- The .dz DTRZ archive layout is fully mapped EXCEPT the per-file
  payload, which uses the proprietary DZ algorithm. CRC32 (big-endian,
  poly 0x04C11DB7) is used for integrity but does not match the high
  bytes of the 16-byte file table entries (those remain unidentified).
- DZ decompression requires porting the algorithm from dzip.exe —
  deferred to Stage 5.x.

### Recovered
- Full outer DTRZ container format: 9-byte header + 224-name list +
  224×6-byte dir-assignment table + 120×16-byte file table + data.
- Confirmation that .atf files use plain zlib (decompresses cleanly).
- .plist atlas format fully documented and parser implemented.
- .fnt bitmap font format fully documented and parser implemented.

### Implemented
- `engine/reverse/plist_atlas.{hpp,cpp}` — Cocos2d-x TexturePacker v2
  atlas parser. Hand-written XML parser (no external deps), parses
  `{x,y}` / `{{x,y},{w,h}}` geometry strings. Handles `rotated`,
  `frame`, `offset`, `sourceColorRect`, `sourceSize`, metadata block.
- `engine/reverse/atf_tactics.{hpp,cpp}` — .atf tactics blob parser.
  zlib-decompresses, parses version + weapon names + binary prefix
  (record_count + stride + unknown), exposes binary records as span.
  Uses system zlib via `<zlib.h>`.
- `engine/reverse/bitmap_font.{hpp,cpp}` — AngelCode BMFont parser.
  Parses `info`, `common`, `page`, `char`, `kerning` lines with
  key=value token parser. Builds char_index and kerning_index for
  O(1) lookup.
- `tests/test_asset_loaders.cpp` — 109 unit tests covering all three
  loaders with synthetic + real-file fixtures.

### Tests
- `test_asset_loaders`: **109/109 passing**.
- Real files tested:
  - `bg.plist` (new_year_dojo location): 2 frames, 512×1024 atlas ✓
  - `_fists.atf`: v=1, weapon B='Fists', stride=858, 1.17 MB records ✓
  - `_batons.atf`: v=1, weapon B='Batons', stride=858, 1.21 MB records ✓
  - `batons_claws.atf`: v=1, A='Batons' B='Claws', stride=858 ✓
  - `kusarigama_nunchaku.atf`: v=1, A='Kusarigama' B='Nunchaku' ✓
  - `CarterOne_numbers_220.fnt`: face='Carter One', 13 chars, 640×640 ✓
- CMake build updated: `engine/reverse/CMakeLists.txt` now links
  `ZLIB::ZLIB` and includes all 4 source files.

### Files changed
- `engine/reverse/plist_atlas.hpp` — new.
- `engine/reverse/plist_atlas.cpp` — new.
- `engine/reverse/atf_tactics.hpp` — new.
- `engine/reverse/atf_tactics.cpp` — new.
- `engine/reverse/bitmap_font.hpp` — new.
- `engine/reverse/bitmap_font.cpp` — new.
- `engine/reverse/CMakeLists.txt` — updated (added 3 new sources, zlib dep).
- `tests/test_asset_loaders.cpp` — new, 109 tests.
- `tests/CMakeLists.txt` — added test_asset_loaders target.
- `CHANGELOG.md` — this entry.

### Notes
- The `.dz` DZ algorithm remains the single blocker for accessing the
  156 game XMLs (including `moves.xml` + `moves.xsd` schema) and all
  `.bin` animation blobs. DZ is Marmalade's proprietary arithmetic
  coding — porting it from dzip.exe is the Stage 5.x task.
- Workaround path remains: frida hook on a real device to dump
  decrypted content.
- All on-disk formats (.plist, .fnt, .atf, .png, .wav, .mp3, .mp4,
  .ttf, .icf) now have working parsers. Stage 7.2 (renderer) can
  proceed using .plist + .png for sprite atlases, and Stage 7.5
  (audio) can use .wav / .mp3 directly.

