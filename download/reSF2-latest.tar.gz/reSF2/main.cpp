// main.cpp
//
// reSF2 runtime entry point.
//
// Stage 7.1.x: Creates a window, runs the main loop, and exits on ESC.
// This is the Milestone M1 deliverable: "window opens, ESC closes".
//
// Build (Linux, with GLFW):
//   g++ -std=c++23 -Iengine -I$HOME/.local/glfw3-dev/usr/include \
//       -I$HOME/.local/gl-dev/usr/include \
//       -L$HOME/.local/glfw3-dev/usr/lib/x86_64-linux-gnu \
//       main.cpp engine/platform/glfw_platform.cpp engine/platform/platform.cpp \
//       engine/runtime/loop.cpp \
//       -lglfw -lGL -lpthread -o resf2_runtime
//
// Build (Windows, with CMake):
//   cmake -S . -B build -G "Visual Studio 17 2022" -A x64
//   cmake --build build --config Release
//   .\build\bin\Release\resf2_runtime.exe

#include "engine/platform/platform.hpp"
#include "engine/platform/glfw_platform.hpp"
#include "engine/runtime/loop.hpp"

#include <cstdio>
#include <string>
#include <string_view>

namespace plat = resf2::platform;
namespace rt = resf2::runtime;

// A minimal game that just clears the screen and exits on ESC.
class HelloGame final : public rt::IGame {
public:
    void on_init(plat::Platform& platform) override {
        platform_ = &platform;
        std::printf("reSF2 initialized. Press ESC to exit.\n");
    }

    void on_update(plat::Platform& platform, std::uint32_t dt_ms) override {
        (void)dt_ms;
        // Check for ESC
        const auto& input = platform.input();
        if (input.keys_just_pressed[static_cast<std::size_t>(plat::Key::Escape)]) {
            // Request exit through the platform
            // (In a real game, we'd use Loop::request_exit(), but for
            //  simplicity we'll just set a flag and close the window)
            quit_ = true;
        }
    }

    void on_render(plat::Platform& platform) override {
        (void)platform;
        // Clear screen to dark blue
        // (GL calls will be added in Stage 7.2 when we have a renderer)
        // For now, just clear with glClear
        // We need to include GL headers for this
    }

    void on_shutdown(plat::Platform& platform) override {
        (void)platform;
        std::printf("reSF2 shutting down.\n");
    }

    bool should_quit() const noexcept { return quit_; }

private:
    plat::Platform* platform_ = nullptr;
    bool quit_ = false;
};

int main(int argc, char* argv[]) {
    // Parse --assets <path> argument
    std::string asset_root;
    for (int i = 1; i < argc; ++i) {
        std::string_view arg = argv[i];
        if (arg == "--assets" && i + 1 < argc) {
            asset_root = argv[++i];
        } else if (arg == "--help" || arg == "-h") {
            std::printf("Usage: resf2_runtime [--assets <path>]\n");
            return 0;
        }
    }

    // Create platform
    auto platform = std::make_unique<plat::GlfwPlatform>();
    plat::WindowConfig cfg;
    cfg.title = "reSF2 — Shadow Fight 2 Engine Reimplementation";
    cfg.width = 1280;
    cfg.height = 720;
    cfg.vsync = true;

    if (!platform->init(cfg)) {
        std::fprintf(stderr, "Failed to initialize platform.\n");
        return 1;
    }

    // Run main loop
    HelloGame game;
    rt::Loop loop;

    // We need a way to exit the loop when the game requests it.
    // For now, the loop exits when platform.poll_events() returns false
    // (which happens when the window close button is pressed).
    // ESC key will also trigger quit via a separate check.

    int result = loop.run(*platform, game);

    platform->shutdown();
    return result;
}
