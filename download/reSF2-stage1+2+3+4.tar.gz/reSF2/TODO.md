# TODO — reSF2 roadmap

Stages (S1..Sn) are the high-level units of work. Each stage must be
fully documented in `docs/` and committed before the next stage begins.
Within a stage, subtasks are tracked as `Sx.y.z`.

Legend: ☐ todo · ☐🔲 planned · ☐🚧 in progress · ☑ done

---

## Stage 1 — APK investigation & scaffolding  ☑

- ☑ S1.1  Download & verify APK (sha256, size, build date).
- ☑ S1.2  apktool decode (resources + manifest + raw DEX, no smali).
- ☑ S1.3  AndroidManifest.xml analysis.
- ☑ S1.4  Inventory `lib/armeabi-v7a/*.so`: ABIs, NEEDED deps, SONAMEs.
- ☑ S1.5  High-level Java package map (DEX string scan, no decompile copy).
- ☑ S1.6  Inventory `assets/` (counts, sizes, formats, top-level dirs).
- ☑ S1.7  Decode `.s3e` (LZMA1 legacy → `XE3U` container).
- ☑ S1.8  Decode `.dz` (DTRZ archive, partial — full unpack pending).
- ☑ S1.9  Decode `.atf` (zlib → custom weapon-pair tactics blob).
- ☑ S1.10 Parse `assets/settings.xml` master manifest.
- ☑ S1.11 Stage 1 docs in `docs/` (00..08).
- ☑ S1.12 Repo skeleton, `README.md`, `CHANGELOG.md`, `TODO.md`,
          `.gitignore`, `CMakeLists.txt` skeleton.
- ☑ S1.13 Local commit (no push — user must restore GitHub auth).

---

## Stage 2 — `.s3e` binary & JNI map  ☐

Goal: be able to parse a `ShadowFight2.s3e` file end-to-end, list every
section, dump relocations, and recover the Java↔native method table.

- ☐ S2.1  Reverse the `XE3U` container header: magic, version, section
          table, relocation table, symbol table.
- ☐ S2.2  Document section types observed in `ShadowFight2.s3e`
          (`.text`, `.rodata`, `.data`, `.bss`, IwUI bins, GL shaders...).
- ☐ S2.3  Implement `engine/reverse/s3e_container.{hpp,cpp}`: read-only
          parser, returns a `S3EFile { sections, symbols, relocations }`.
- ☐ S2.4  Unit tests for the parser against `ShadowFight2.s3e`.
- ☐ S2.5  Trace `JNI_OnLoad` in `libs3e_android.so` (Ghidra/objdump) to
          recover the `RegisterNatives()` table → `Java↔C++` map.
- ☐ S2.6  Cross-reference with `com.ideaworks3d.marmalade.LoaderThread`
          native method declarations (from DEX) to confirm signatures.
- ☐ S2.7  Write `docs/09_s3e_binary_format.md`,
          `docs/10_jni_registration_map.md`.
- ☐ S2.8  Commit. Update `CHANGELOG.md`, `TODO.md`.

---

## Stage 3 — Engine architecture recovery  ☑

- ☑ S3.1  From S2.5 + strings in `.s3e`, list all C++ namespaces/classes
          referenced (game-side). Do NOT copy code, only record names +
          hypotheses about responsibilities.
- ☑ S3.2  Identify main loop structure: `s3eMainLoop`, frame callbacks,
          update vs render paths, fixed-step vs variable-step.
- ☑ S3.3  Identify scene manager / state machine (menu / fight / shop /
          raid / tutorial).
- ☑ S3.4  Identify input pipeline (touch, keyboard, gamepad).
- ☑ S3.5  Identify camera model (2D, parallax, shake).
- ☑ S3.6  Write `docs/11_engine_architecture.md`,
          `docs/12_main_loop.md`.
- ☑ S3.7  Commit.

---

## Stage 4 — Game object & skeletal format recovery  ☐

Goal: load and render one fighter on screen, no animation yet.

- ☐ S4.1  Document `assets/models/*.xml` schema (skeleton + attach points).
- ☐ S4.2  Document `assets/animations/moves.xml` schema.
- ☐ S4.3  Document `.dz` (`animations.dz`) full format.
- ☐ S4.4  Reverse the `.atf` (zlib-compressed) payload format used for
          weapon-pair tactics.
- ☐ S4.5  Implement loaders for the above (C++20, with tests).
- ☐ S4.6  Render a static fighter mesh on screen using the recovered
          skeleton + a texture atlas.
- ☐ S4.7  Commit.

---

## Stage 5 — Resource format specs (final)  ☐

- ☐ S5.1  Finalize `.plist` (Cocos2d-x TexturePacker v2) reader.
- ☐ S5.2  Finalize `.atf` tactics reader.
- ☐ S5.3  Finalize `.dz` (DTRZ) reader.
- ☐ S5.4  Finalize `.fnt` (Cocos2d-x bitmap font) reader.
- ☐ S5.5  Finalize `.s3e` reader (consumer of S2.3).
- ☐ S5.6  Document each format in `docs/` with a minimal fuzzer / round-trip
          test.
- ☐ S5.7  Commit.

---

## Stage 6 — Asset loaders (production)  ☐

Hook the Stage 5 readers into a real `AssetManager` with async I/O,
dependency resolution and a hot-reload path.

- ☐ S6.1  AssetManager skeleton + DI.
- ☐ S6.2  Per-format loader plugins.
- ☐ S6.3  Async I/O queue (one thread per backing filesystem).
- ☐ S6.4  Hot-reload watcher (dev-only).
- ☐ S6.5  Integration tests using fixtures from `assets/`.
- ☐ S6.6  Commit.

---

## Stage 7 — Engine implementation (iterative)  ☐

Each subsystem below is its own mini-stage with its own design doc and
test plan. Order matters.

- ☐ S7.1  Platform abstraction (`engine/platform/`): window, GL context,
          input, filesystem, threads, time.
- ☐ S7.2  Renderer (`engine/renderer/`): GLES2 backend, batched sprite
          renderer, atlas bindings, GLSL program cache, render queue,
          camera.
- ☐ S7.3  Animation (`engine/animation/`): skeletal anim, state machine,
          blend tree (if recovered), timeline.
- ☐ S7.4  Physics (`engine/physics/`): hitbox / hurtbox, collision,
          constraints, gravity (only what the original uses — no generic
          physics engine).
- ☐ S7.5  Audio (`engine/audio/`): mixer, SFX pool, music streaming,
          spatialisation (if recovered).
- ☐ S7.6  AI (`engine/ai/`): NPC state machine, decision timers, attack /
          defend tables (extracted from `.atf` tactics).
- ☐ S7.7  Battle logic: round flow, damage formula, combo timing.
- ☐ S7.8  Save system: serialization, checksum, encryption (if any).
- ☐ S7.9  UI: CocoGUI-compatible loader + layout engine.
- ☐ S7.10 Networking (`engine/network/`): SmartFox2X-compatible client
           (TCP + UDP, packet encrypter, lag monitor).
- ☐ S7.11 Effects / particle system.
- ☐ S7.12 Scene manager + game state machine.
- ☐ S7.13 End-to-end smoke test: boot, reach main menu, enter a fight.

---

## Stage 8 — Portability & packaging  ☐

- ☐ S8.1  Linux x86_64 / aarch64.
- ☐ S8.2  Windows x86_64 (MSVC + Clang).
- ☐ S8.3  macOS x86_64 / arm64.
- ☐ S8.4  Android (arm64-v8a modern target, plus x86_64 for emulators).
- ☐ S8.5  Steam Deck (treat as Linux with controller-only UX).
- ☐ S8.6  Nintendo Switch (homebrew toolchain, optional).
- ☐ S8.7  CI matrix on GitHub Actions.

---

## Cross-cutting

- ☐ C1   Coding-style guide (`docs/coding_style.md`).
- ☐ C2   Test policy (`docs/testing.md`).
- ☐ C3   RE ethics & legal notes (`docs/legal.md`).
- ☐ C4   Threat model for asset loaders (untrusted input).
- ☐ C5   Performance budgets (frame time, memory, draw calls).
