# reSF2

Clean-room reimplementation of the engine behind **Shadow Fight 2** (Android
v1.9.21, package `com.nekki.shadowfight`, versionCode `1000086`).

> ## ⚠️ Legal & ethical scope
>
> This project is a **clean-room reimplementation**. We:
>
> - inspect the publicly distributed APK to **understand** file formats,
>   engine architecture and observable runtime behaviour;
> - **never** copy or republish original source code, art, audio, or any
>   copyrighted asset;
> - write **new** C++20 code that can load and execute the original game's
> data files in a compatible way, for the purposes of **interoperability,
> preservation and education**.
>
> The repository contains **no original game assets**. End users must supply
> their own legally obtained copy of the game. The intent is the same as
> projects such as *scummvm*, *reicast*, *OpenMW*, *OpenRA*.

## Why this exists

Shadow Fight 2 is built on the **Marmalade SDK** (v8.2.1, formerly
Airplay SDK). Marmalade has been EOL since 2017 and the original 32-bit
ARMv7 build will stop running on modern Android / iOS / desktop platforms.
reSF2 aims to provide a portable, 64-bit, multi-platform runtime that can
load the game's `ShadowFight2.s3e` binary and the Marmalade asset formats
in a behaviour-compatible way.

## Status

| Stage | Title                                   | Status |
| ----- | --------------------------------------- | ------ |
| 1     | APK investigation & project scaffolding | ✅ done |
| 2     | `.s3e` binary structure & loader        | 🔜 next |
| 3     | Engine architecture recovery            | planned |
| 4     | Game object / skeletal format recovery  | planned |
| 5     | Resource format specs (final)           | planned |
| 6     | Asset loaders                           | planned |
| 7     | Engine implementation (iterative)       | planned |

See [`TODO.md`](TODO.md) and [`CHANGELOG.md`](CHANGELOG.md) for the detailed
roadmap and progress log. Stage-by-stage findings live in [`docs/`](docs/).

## Repository layout

```
reSF2/
├── engine/        portable C++20 engine (target)
│   ├── runtime/   main loop, scheduler, scene manager
│   ├── renderer/  GLES2-compatible renderer
│   ├── physics/   collision / hitbox / hurtbox
│   ├── animation/ skeletal anim, state machine
│   ├── audio/     mixer, sfx, music
│   ├── network/   SmartFox-compatible client
│   ├── platform/  Android / Linux / Windows / macOS / Switch / Steam Deck
│   ├── tools/     offline asset tools
│   └── reverse/   RE notes, IDA/Ghidra scripts, format parsers
├── docs/          per-stage engineering documentation
├── tests/         per-subsystem unit / integration tests
├── assets/        sample asset fixtures (small, non-copyrighted)
└── scripts/       build / CI helpers
```

## Build (planned)

```bash
cmake -S . -B build -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE=cmake/toolchain-linux-x86_64.cmake
cmake --build build
ctest --test-dir build --output-on-failure
```

Toolchains: Clang ≥ 16, GCC ≥ 13, MSVC 19.37+. C++20 minimum, C++23 where
available. No globals, no magic numbers, RAII throughout, `std::unique_ptr`
by default, `std::shared_ptr` only where ownership is genuinely shared.

## Contributing

Work proceeds in **stages**. Do not skip ahead. Each stage must produce:

1. `docs/<stage>_<topic>.md` notes
2. Code (if any) with tests
3. A local commit with a clear message
4. `CHANGELOG.md` + `TODO.md` updated

## Acknowledgements

- **Nekki** — original game developer.
- **Marmalade Technologies** — original SDK author (now EOL).
- **SmartFoxServer (Sfs2X)** — original multiplayer backend.
- Open-source RE community: *apktool* (iBotPeaches), *jadx* (skylot).
