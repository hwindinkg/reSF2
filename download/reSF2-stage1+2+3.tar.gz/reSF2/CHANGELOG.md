# Changelog

All notable changes to reSF2 are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project
aims for [Semantic Versioning](https://semver.org/) once v1.0 is reached.

Stages are the high-level units of progress (see `TODO.md`).

## [Unreleased]

### Stage 1 — APK investigation & project scaffolding  (2026-07-09)

#### Investigated
- Downloaded and verified Shadow Fight 2 v1.9.21 APK
  (`sha256=9258146bb87e7d1010ebbd6cc9f7bc9f00f1f2ff61ae4a73cd29003b072f5143`,
  94 736 412 bytes, build date 2016-06-09).
- Decoded AndroidManifest.xml, apktool.yml, both DEX files, all native
  libraries and the full asset tree.
- Determined that the game runs on **Marmalade SDK v8.2.1** (formerly
  Airplay SDK), single ABI `armeabi-v7a`, OpenGL ES 2.0, landscape.
- Identified that the actual game logic is shipped inside the
  LZMA-compressed `assets/ShadowFight2.s3e` binary (magic `XE3U`,
  2 858 937 → 8 689 357 bytes), not inside a Java class or a regular
  `lib*.so` next to `libs3e_android.so`.
- Mapped 30 native libraries under `lib/armeabi-v7a/`, classified by role
  (Marmalade runtime, SmartFox2X client, FFmpeg 2.x family, controller
  input, haptics, 23 `s3e*` platform extensions for ads / IAP / analytics).
- Mapped ~10 300 Java classes; only `com.nekki.shadowfight.Main` is the
  entry activity. Everything else is third-party ad/IAP/analytics SDK plus
  Marmalade's `com.ideaworks3d.marmalade.*` glue layer.
- Catalogued 1 866 asset files (PNG 1 333, plist 148, ATF-style 110,
  XML 77, WAV 76, JPG 70, FNT 16, JSON 11, MP3 5, DTRZ .dz 2, MP4 1, INI 1).
- Decoded the ATF-style files: they are zlib-compressed custom blobs whose
  payload is weapon-pair combat tactics (e.g. `batons_claws.atf` describes
  the batons-vs-claws exchange table). Not Adobe Texture Format.
- Decoded the DTRZ `.dz` files: custom archive format (magic `DTRZ`)
  holding multiple XML data files (animation defs, file manifest).
- Parsed `assets/settings.xml`: this is the master manifest listing every
  gameplay XML (achievements, quests, perks, models, localizations, raid
  stages, tactic settings, user defaults, etc.).

#### Recovered
- Engine identity and version: **Marmalade v8.2.1 build 465988**.
- The shape of the S3E binary container (LZMA1 wrapper + `XE3U` sectioned
  payload with embedded Marmalade config text + ARM `.text` segment).
- JNI registration model: `libs3e_android.so` exports only `JNI_OnLoad` /
  `JNI_OnUnLoad` — all native methods are registered dynamically via
  `RegisterNatives()`, so we must trace `JNI_OnLoad` to recover the
  Java↔native symbol map (deferred to Stage 2).
- Networking stack: SmartFoxServer 2X C++ API (`Sfs2X::*` namespaces in
  `libsmartfox.so`, built on `boost::asio` TCP/UDP, with `ConfigLoader`,
  `BitSwarmClient`, `LagMonitor`, packet encrypter).
- Video stack: FFmpeg 2.x (`libavcodec-55`, `libavformat-55`, `libavutil-52`,
  `libswscale-2`) exposed via `libs3eFfmpeg.so`.
- Asset layout: two asset scales (`1536/` and `768/`), 50+ battle locations,
  110 weapon-vs-weapon tactics files, 12 localizations (chn, chn_tr, eng,
  fra, ger, ita, jpn, kor, por, rus, spa, tur).

#### Implemented
- Repository skeleton: `engine/{runtime,renderer,physics,animation,audio,
  network,platform,tools,reverse}`, `docs/`, `tests/`, `assets/`,
  `scripts/`.
- `README.md`, `CHANGELOG.md`, `TODO.md`, `.gitignore`.
- Top-level `CMakeLists.txt` skeleton (C++20, no targets yet — first
  real targets land in Stage 2).
- Stage 1 documentation set in `docs/`:
  - `00_stage1_summary.md`
  - `01_apk_structure.md`
  - `02_native_libraries.md`
  - `03_java_layer.md`
  - `04_assets_inventory.md`
  - `05_resource_formats.md`
  - `06_engine_marmalade.md`
  - `07_jni_and_loader.md`
  - `08_reverse_engineering_log.md`

#### Tests
- No code yet → no tests. Stage 2 will introduce the first unit tests
  for the LZMA1 + `XE3U` container parser.

#### Files changed
- `README.md`, `CHANGELOG.md`, `TODO.md`, `.gitignore`,
  `CMakeLists.txt`, `engine/.keep`, `tests/.keep`, `assets/.keep`,
  `scripts/.keep`, `docs/00_stage1_summary.md`,
  `docs/01_apk_structure.md`, `docs/02_native_libraries.md`,
  `docs/03_java_layer.md`, `docs/04_assets_inventory.md`,
  `docs/05_resource_formats.md`, `docs/06_engine_marmalade.md`,
  `docs/07_jni_and_loader.md`, `docs/08_reverse_engineering_log.md`.

#### Notes
- User-supplied GitHub PAT was exposed in the originating chat. It was
  **not** used during this stage. The user must revoke it and reconfigure
  auth locally before pushing this commit.

## Stage 2 — `.s3e` binary & JNI map  (2026-07-09)

### Investigated
- Decompressed `ShadowFight2.s3e` (LZMA1 legacy, 2 858 937 -> 8 689 357 B)
  and mapped the inner `XE3U` container header (76 bytes / 19 u32 fields).
- Located and documented three payload sections:
  - Embedded Marmalade config text (offset 0x4c, length 5 333 B) — the
    global `s3e.icf` with the runtime extension list at the end.
  - Import-name table (offset 0x1521, ~10 KB) — 346 valid C-identifier
    function names that the game imports from the Marmalade loader
    (117 `s3e*`, 210 `gl*`, 19 other).
  - Relocation table (offset 0x2bbf, ~266 KB) — GOT-reference array
    pointing to slots at vaddr 0x007b8000. Full layout deferred to
    Stage 4 (not needed for clean-room).
- Located 17 GLSL shader sources in the `.rodata` region (offset
  0x768ee9..0x76b000). All use GLES2 syntax; many use Cocos2d-x
  naming (`CC_Texture0`, `v_fragmentColor`, `v_texCoord`).
- Disassembled `JNI_OnLoad` (file offset 0x3c770, ARM mode) via
  Python + Capstone 5.0.7 — system `objdump` lacks ARM support.
  `JNI_OnLoad` is a thin shim: stores `JavaVM*`, clears a flag, calls
  `_s3eAndroidInit` at 0x3c698, returns `JNI_VERSION_1_4`.
- Recovered ~110 Java native method names + 24 JNI signatures +
  14 Java class references from string analysis of
  `libs3e_android.so` `.rodata`. Categories: lifecycle, input,
  audio, video, haptics, filesystem, device info.

### Recovered
- The complete Marmalade SDK API surface the game uses (346 imports).
  This is the contract reSF2's runtime must provide.
- All 17 GLSL shaders the game uses for sprite rendering, alpha-test,
  masking, and color-fill.
- The Java↔native dispatch shape: one `JNI_OnLoad` registers ~110
  native methods on 4 Marmalade Java classes (`LoaderThread`,
  `LoaderView`, `LoaderKeyboard`, `LoaderThread$MediaPlayerManager`).

### Implemented
- `engine/reverse/s3e_container.{hpp,cpp}` — read-only C++23 parser
  for the `XE3U` container. Validates magic, parses the 76-byte
  header, exposes the embedded config text, and extracts the
  import-name table. Uses `std::expected` + `std::span` for borrow
  safety; no exceptions in the parser path.
- `engine/reverse/CMakeLists.txt` — defines `libresf2_reverse.a`
  static library target.
- `tests/test_s3e_container.cpp` — 24 unit tests (synthetic data +
  real-file fixture). Covers: empty/too-small/bad-magic rejection,
  minimal valid file parse, real `ShadowFight2.bin` parse with
  spot-checks on header fields, config text, and import names.
- `engine/reverse/s3e_imports.txt` — full 346-entry import list.
- `engine/reverse/s3e_shaders.txt` — full 17-shader source dump.
- `docs/09_s3e_binary_format.md` — `XE3U` container spec.
- `docs/10_jni_registration_map.md` — JNI surface map.

### Tests
- `test_s3e_container`: 24/24 passing.
- CMake build (C++23, g++ 14.2.0): `cmake -S . -B build-cmake`,
  `cmake --build build-cmake`, `ctest --test-dir build-cmake` →
  `100% tests passed, 0 tests failed out of 1`.
- Standalone build: `g++ -std=c++23 -Iengine tests/test_s3e_container.cpp
  engine/reverse/s3e_container.cpp -o build/test_s3e_container` → passes.

### Files changed
- `CMakeLists.txt` — bumped to C++23, version 0.0.2.
- `engine/CMakeLists.txt` — updated comment (Stage 2 introduces first
  real target).
- `engine/reverse/CMakeLists.txt` — new, defines `libresf2_reverse`.
- `engine/reverse/s3e_container.hpp` — new, public parser API.
- `engine/reverse/s3e_container.cpp` — new, parser implementation.
- `engine/reverse/s3e_imports.txt` — new, 346 import names.
- `engine/reverse/s3e_shaders.txt` — new, 17 GLSL shaders.
- `tests/CMakeLists.txt` — defines `test_s3e_container`.
- `tests/test_s3e_container.cpp` — new, 24 tests.
- `docs/09_s3e_binary_format.md` — new.
- `docs/10_jni_registration_map.md` — new.
- `.gitignore` — added `tests/fixtures/`, `ShadowFight2.bin`.

### Notes
- The original `ShadowFight2.bin` (8.69 MB decompressed S3E payload)
  is placed under `tests/fixtures/` locally for the real-file test
  but is `.gitignored` — the repo never ships original game binaries.
- CMake 4.3.4 was installed via `pip install cmake` (no sudo needed).
  Capstone 5.0.7 was installed via `pip install capstone` for ARM
  disassembly in the RE scripts.
- Stage 2.6 (exact `JNINativeMethod[]` array offset) is deferred —
  requires Ghidra or IDA. Not needed for clean-room reimplementation.

## Stage 3 — Engine architecture recovery  (2026-07-09)

### Investigated
- Mined 9 330 unique C++ identifiers from `.s3e` `.rodata` (excluding
  the import table region 0x1521–0x2bbf). 85 game-side classes
  recovered with at least one `Class::method` reference; 250+ methods
  catalogued in `engine/reverse/s3e_classes.txt`.
- Identified the rendering layer as **Cocos2d-x 2.x-style** (236 refs
  to `cocos2d`, plus `CCNode`, `CCSprite`, `CCDirector`, `CCScene`,
  `CCLayer`, `CCAction`, `CCAnimation`, `CCAnimate`, `CCSpriteFrame`,
  `CCSpriteBatchNode`, `CCTexture2D`, `CCTextureCache`,
  `CCRenderTexture`, `CCScrollView`, `CCParticle`, `CCLabelTTF`,
  `CCLabelBMFont`, `CCTouch`, `CCEGLView`). Nekki wrote their own
  thin layer that mimics the Cocos2d-x 2.x API — this is NOT the
  official Cocos2d-x Marmalade port.
- Identified XML parsers: **pugixml** (primary, 4 refs) +
  **tinyxml** (secondary, 15 refs). Both MIT-licensed; reSF2 will
  vendor both unchanged.
- Identified save system: `assets/localSettings.bin`, AES-encrypted
  (strings `error during encryption`, `error during decryption`,
  `AES128-CBC-SHA`, `AES256-CBC-SHA`). `UserDefault.xml` stores
  only non-sensitive UI settings.
- Confirmed physics is **fully custom** — no Box2D / Chipmunk /
  Bullet / ODE / Tokamak references. Collision is direct
  rectangle-vs-rectangle testing driven by `.atf` tactics data.
- Confirmed networking uses SmartFoxServer 2X for raids: `BitSwarmClient`,
  `UDPManager`, `TCPSocketLayer`, `UDPSocketLayer`, `SFSProtocolCodec`,
  `DefaultPacketEncrypter`, `SystemController`, `ExtensionController`,
  `LagMonitor`, `ConfigLoader`, `LoginRequest`.
- Identified main loop as **single-threaded, variable-step**, driven
  by `s3eTimerGetMs()` with `dt` clamped to 200 ms (Cocos2d-x 2.x
  convention). Only 1 import of `s3eThreadCreate` — no worker thread
  pool. Audio runs on a separate Marmalade-managed thread.
- Identified camera: 2D orthographic, follow-the-player scroll,
  shake on heavy hits, zoom on critical moments.

### Recovered
- Game-side class inventory: 85 classes organised into 7 categories
  (orchestration, battle, models, quests, items, UI, multiplayer,
  ads/IAP). See `engine/reverse/s3e_classes.txt`.
- Layered architecture: game logic → Cocos2d-x 2.x-style layer →
  pugixml/tinyxml → SmartFox2X → Marmalade SDK → Android.
- Main loop structure: init → loop{yield, poll, update, render,
  present} → shutdown. Detailed in `docs/12_main_loop.md`.
- Per-subsystem update order (10 phases, from input to audio).
- Frame timing budget: 15 ms / frame at 60 FPS target.
- Pause/resume semantics: `nativePause` flag, audio thread stays
  alive, network socket kept open with LagMonitor keep-alive.
- Fixed-step vs variable-step: **variable-step** confirmed (`.atf`
  tactics store frame windows in milliseconds, not frame counts).

### Implemented
- `docs/11_engine_architecture.md` — full recovered architecture
  with class inventory, layered diagram, and reSF2 target architecture.
- `docs/12_main_loop.md` — main loop pseudocode, update order,
  frame timing budget, pause/resume, fixed-step decision.
- `engine/reverse/s3e_classes.txt` — 85 game classes with method
  lists.

### Files changed
- `docs/11_engine_architecture.md` — new.
- `docs/12_main_loop.md` — new.
- `docs/README.md` — updated Stage 2/3 sections.
- `engine/reverse/s3e_classes.txt` — new, 85 classes.
- `TODO.md` — Stage 3 marked complete.
- `CHANGELOG.md` — this entry.

### Notes
- Cocos2d-x 2.x API surface is public and MIT-licensed — reSF2 can
  re-implement `CCNode`/`CCSprite`/`CCDirector`/etc cleanly without
  copying any Nekki code. This significantly de-risks Stage 7.2
  (renderer).
- The `localSettings.bin` AES key is not yet recovered — needs a
  runtime trace or known-plaintext attack on a real save file
  (Stage 7.8 task).
- Stage 4 (game object & skeletal format recovery) is next: full
  `.dz` DTRZ archive unpack + `moves.xml` schema + `.atf` tactics
  byte layout, plus a C++20 reader for each.

